import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B0m-tNXj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_DB = {
	players: [],
	sessions: [],
	activePlayerId: null
};
var TAB_SCREENS = [
	"home",
	"sessions",
	"analyze",
	"players",
	"more"
];
var DAY = 864e5;
function del(kmh, ts, confidence = "high", extras = {}) {
	const time = 20.12 / (kmh / 3.6);
	return {
		kmh,
		mph: kmh * .621371,
		time,
		distance: 20.12,
		fps: 60,
		confidence,
		angle: "side",
		bounce: null,
		ts,
		...extras
	};
}
function makeSeed(now = Date.now()) {
	const players = [
		{
			id: "p_arjun",
			name: "Arjun Mehta",
			hand: "Right-handed",
			style: "Fast",
			team: "VoxVelo Academy",
			createdAt: now - 20 * DAY
		},
		{
			id: "p_priya",
			name: "Priya Sharma",
			hand: "Right-handed",
			style: "Medium",
			team: "VoxVelo Academy",
			createdAt: now - 18 * DAY
		},
		{
			id: "p_kabir",
			name: "Kabir Singh",
			hand: "Left-handed",
			style: "Spin",
			team: "City Club",
			createdAt: now - 12 * DAY
		}
	];
	const sMorning = {
		id: "s_morning",
		name: "Morning Nets",
		playerId: "p_arjun",
		createdAt: now - 2 * DAY,
		deliveries: [
			del(136.2, now - 2 * DAY + 48e4),
			del(138.5, now - 2 * DAY + 72e4),
			del(141.1, now - 2 * DAY + 96e4),
			del(139.4, now - 2 * DAY + 12e5),
			del(137.8, now - 2 * DAY + 144e4),
			del(135, now - 2 * DAY + 168e4, "medium"),
			del(133.6, now - 2 * DAY + 192e4),
			del(132.1, now - 2 * DAY + 216e4, "medium")
		]
	};
	const sEvening = {
		id: "s_evening",
		name: "Evening Spell",
		playerId: "p_arjun",
		createdAt: now - 216e5,
		deliveries: [
			del(134.8, now - 216e5 + 24e4),
			del(137.2, now - 216e5 + 48e4),
			del(138.9, now - 216e5 + 72e4),
			del(136.4, now - 216e5 + 96e4),
			del(133.1, now - 216e5 + 12e5, "medium"),
			del(131.8, now - 216e5 + 144e4)
		]
	};
	const sYorkers = {
		id: "s_yorkers",
		name: "Nets — Yorkers",
		playerId: "p_priya",
		createdAt: now - 3 * DAY,
		deliveries: [
			del(118.4, now - 3 * DAY + 6e5),
			del(121, now - 3 * DAY + 84e4),
			del(119.6, now - 3 * DAY + 108e4),
			del(116.2, now - 3 * DAY + 132e4, "medium"),
			del(114.8, now - 3 * DAY + 156e4),
			del(112.5, now - 3 * DAY + 18e5, "low")
		]
	};
	return {
		players,
		sessions: [
			sEvening,
			{
				id: "s_spin",
				name: "Off-spin block",
				playerId: "p_kabir",
				createdAt: now - DAY,
				deliveries: [
					del(84.2, now - DAY + 3e5),
					del(86.1, now - DAY + 54e4),
					del(87.8, now - DAY + 78e4),
					del(85.4, now - DAY + 102e4),
					del(83, now - DAY + 126e4, "medium"),
					del(81.6, now - DAY + 15e5),
					del(80.2, now - DAY + 174e4, "medium")
				]
			},
			sMorning,
			sYorkers
		],
		activePlayerId: "p_arjun"
	};
}
var DB_KEY = "voxvelo_v1";
function isDb(value) {
	if (!value || typeof value !== "object") return false;
	const v = value;
	return Array.isArray(v.players) && Array.isArray(v.sessions);
}
function loadDB() {
	if (typeof window === "undefined") return EMPTY_DB;
	try {
		const raw = localStorage.getItem(DB_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			if (isDb(parsed)) return parsed;
		}
	} catch {}
	const seeded = makeSeed();
	try {
		localStorage.setItem(DB_KEY, JSON.stringify(seeded));
	} catch {}
	return seeded;
}
function saveDB(db) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(DB_KEY, JSON.stringify(db));
	} catch {}
}
async function exportDB(db) {
	const json = JSON.stringify(db, null, 2);
	const filename = `voxvelo-export-${Date.now()}.json`;
	const blob = new Blob([json], { type: "application/json" });
	const file = new File([blob], filename, { type: "application/json" });
	const nav = navigator;
	if (nav.share && nav.canShare?.({ files: [file] })) try {
		await nav.share({
			files: [file],
			title: "VoxVelo export"
		});
		return "shared";
	} catch (err) {
		if (err.name === "AbortError") return "shared";
	}
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = filename;
	a.click();
	URL.revokeObjectURL(a.href);
	return "downloaded";
}
function fmt(n, d = 1) {
	if (n === null || n === void 0 || Number.isNaN(n)) return "—";
	return Number(n).toFixed(d);
}
function kmhToMph(k) {
	return k * .621371;
}
function timeAgo(ts, now = Date.now()) {
	const s = (now - ts) / 1e3;
	if (s < 3600) return `${Math.max(1, Math.round(s / 60))}m ago`;
	if (s < 86400) return `${Math.round(s / 3600)}h ago`;
	return `${Math.round(s / 86400)}d ago`;
}
function uid(prefix) {
	return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
var toastTimer = null;
function persist(get) {
	const { players, sessions, activePlayerId } = get();
	saveDB({
		players,
		sessions,
		activePlayerId
	});
}
function applyHistory(screen, payload, isTab) {
	if (typeof window === "undefined") return;
	const hash = payload ? `#${screen}/${payload}` : `#${screen}`;
	const state = {
		screen,
		payload
	};
	if (isTab) window.history.replaceState(state, "", hash);
	else window.history.pushState(state, "", hash);
}
var useVox = create((set, get) => ({
	...EMPTY_DB,
	hydrated: false,
	screen: "home",
	screenPayload: null,
	currentSessionId: null,
	toast: null,
	confirm: null,
	playerModalOpen: false,
	sessionModalOpen: false,
	sessionModalMode: "create",
	pendingDelivery: null,
	hydrate: () => {
		if (get().hydrated) return;
		const db = loadDB();
		let screen = "home";
		let payload = null;
		if (typeof window !== "undefined") {
			const [name, id] = window.location.hash.replace(/^#/, "").split("/");
			if (name && [
				"home",
				"sessions",
				"session-detail",
				"analyze",
				"players",
				"player-detail",
				"team-dashboard",
				"compare",
				"more"
			].includes(name)) {
				screen = name;
				payload = id || null;
			}
			window.history.replaceState({
				screen,
				payload
			}, "", payload ? `#${screen}/${payload}` : `#${screen}`);
			window.addEventListener("popstate", (e) => {
				const s = e.state;
				if (s?.screen) {
					set({
						screen: s.screen,
						screenPayload: s.payload ?? null
					});
					window.scrollTo(0, 0);
				}
			});
		}
		set({
			...db,
			hydrated: true,
			screen,
			screenPayload: payload
		});
	},
	goto: (screen, payload = null) => {
		applyHistory(screen, payload, TAB_SCREENS.includes(screen));
		set({
			screen,
			screenPayload: payload
		});
		if (typeof window !== "undefined") window.scrollTo(0, 0);
	},
	showToast: (message) => {
		if (toastTimer) clearTimeout(toastTimer);
		set({ toast: message });
		toastTimer = setTimeout(() => set({ toast: null }), 2800);
	},
	clearToast: () => set({ toast: null }),
	askConfirm: (c) => set({ confirm: c }),
	closeConfirm: () => set({ confirm: null }),
	openPlayerModal: () => set({ playerModalOpen: true }),
	closePlayerModal: () => set({ playerModalOpen: false }),
	openSessionModal: (mode, pending = null) => set({
		sessionModalOpen: true,
		sessionModalMode: mode,
		pendingDelivery: pending
	}),
	closeSessionModal: () => set({
		sessionModalOpen: false,
		pendingDelivery: null
	}),
	addPlayer: (input) => {
		const player = {
			...input,
			id: uid("p"),
			createdAt: Date.now()
		};
		set((s) => ({
			players: [...s.players, player],
			activePlayerId: s.activePlayerId ?? player.id,
			playerModalOpen: false
		}));
		persist(get);
		return player;
	},
	setActivePlayer: (id) => {
		set({ activePlayerId: id });
		persist(get);
	},
	addSession: (name, playerId) => {
		const session = {
			id: uid("s"),
			name,
			playerId,
			createdAt: Date.now(),
			deliveries: []
		};
		set((s) => ({
			sessions: [session, ...s.sessions],
			currentSessionId: session.id,
			sessionModalOpen: false,
			pendingDelivery: null
		}));
		persist(get);
		return session;
	},
	addDelivery: (sessionId, delivery) => {
		set((s) => ({
			sessions: s.sessions.map((sess) => sess.id === sessionId ? {
				...sess,
				deliveries: [...sess.deliveries, delivery]
			} : sess),
			currentSessionId: sessionId
		}));
		persist(get);
	},
	savePendingDelivery: (name, playerId) => {
		const pending = get().pendingDelivery;
		const session = {
			id: uid("s"),
			name,
			playerId,
			createdAt: Date.now(),
			deliveries: pending ? [{ ...pending }] : []
		};
		set((s) => ({
			sessions: [session, ...s.sessions],
			currentSessionId: session.id,
			sessionModalOpen: false,
			pendingDelivery: null
		}));
		persist(get);
		return session;
	},
	exportData: async () => {
		const { players, sessions, activePlayerId, showToast } = get();
		showToast(await exportDB({
			players,
			sessions,
			activePlayerId
		}) === "shared" ? "Export shared." : "Export downloaded.");
	},
	clearAllData: () => {
		saveDB(EMPTY_DB);
		set({
			...EMPTY_DB,
			currentSessionId: null,
			confirm: null
		});
		get().showToast("Local data cleared.");
	}
}));
function SpeedChart({ deliveries }) {
	const pad = 10;
	if (!deliveries.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 320 120",
		width: "100%",
		height: "120",
		"aria-label": "Speed chart",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "160",
			y: "60",
			fill: "#5B677A",
			fontSize: "11",
			textAnchor: "middle",
			children: "No data yet"
		})
	});
	const speeds = deliveries.map((d) => d.kmh);
	const min = Math.min(...speeds);
	const range = Math.max(...speeds) - min || 1;
	const pts = speeds.map((v, i) => {
		return [pad + i / Math.max(1, speeds.length - 1) * 300, 110 - (v - min) / range * 100];
	});
	const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 320 120",
		width: "100%",
		height: "120",
		"aria-label": "Speed by delivery",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: path,
			fill: "none",
			stroke: "#2DD4BF",
			strokeWidth: "1.6"
		}), pts.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: p[0].toFixed(1),
			cy: p[1].toFixed(1),
			r: "2.6",
			fill: "#FF4B3E"
		}, i))]
	});
}
function HistogramChart({ deliveries }) {
	const w = 150;
	const h = 90;
	const pad = 8;
	const speeds = deliveries.map((d) => d.kmh);
	if (speeds.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 150 90",
		width: "100%",
		height: "90",
		"aria-label": "Speed distribution",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: w / 2,
			y: h / 2,
			fill: "#5B677A",
			fontSize: "9",
			textAnchor: "middle",
			children: "Needs 2+ deliveries"
		})
	});
	const min = Math.min(...speeds);
	const range = Math.max(...speeds) - min || 1;
	const bucketCount = 5;
	const buckets = new Array(bucketCount).fill(0);
	speeds.forEach((v) => {
		let idx = Math.floor((v - min) / range * bucketCount);
		if (idx >= bucketCount) idx = 4;
		if (idx < 0) idx = 0;
		buckets[idx] += 1;
	});
	const maxCount = Math.max(...buckets);
	const bw = 134 / bucketCount;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 150 90",
		width: "100%",
		height: "90",
		"aria-label": "Speed distribution",
		children: [buckets.map((c, i) => {
			const bh = maxCount ? c / maxCount * 62 : 0;
			const x = pad + i * bw;
			const y = 82 - bh;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: (x + 2).toFixed(1),
				y: y.toFixed(1),
				width: 22.8.toFixed(1),
				height: bh.toFixed(1),
				fill: "#2DD4BF",
				rx: "2"
			}, i);
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: pad,
			y1: 82,
			x2: 142,
			y2: 82,
			stroke: "#26304366"
		})]
	});
}
function ProgressChart({ deliveries }) {
	const w = 150;
	const h = 90;
	const pad = 8;
	if (!deliveries.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 150 90",
		width: "100%",
		height: "90",
		"aria-label": "Session progress",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: w / 2,
			y: h / 2,
			fill: "#5B677A",
			fontSize: "9",
			textAnchor: "middle",
			children: "No data yet"
		})
	});
	const speeds = deliveries.map((d) => d.kmh);
	const cum = [];
	let sum = 0;
	speeds.forEach((v, i) => {
		sum += v;
		cum.push(sum / (i + 1));
	});
	const min = Math.min(...cum);
	const range = Math.max(...cum) - min || 1;
	const path = cum.map((v, i) => {
		return [pad + i / Math.max(1, cum.length - 1) * 134, 82 - (v - min) / range * 74];
	}).map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 150 90",
		width: "100%",
		height: "90",
		"aria-label": "Fatigue trend",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: path,
			fill: "none",
			stroke: "#F4B740",
			strokeWidth: "1.6"
		})
	});
}
function TrendChart({ values }) {
	const w = 320;
	const h = 120;
	const pad = 10;
	if (values.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 320 120",
		width: "100%",
		height: "120",
		"aria-label": "Performance trend",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: w / 2,
			y: h / 2,
			fill: "#5B677A",
			fontSize: "11",
			textAnchor: "middle",
			children: "Needs 2+ sessions with deliveries"
		})
	});
	const min = Math.min(...values);
	const range = Math.max(...values) - min || 1;
	const pts = values.map((v, i) => {
		return [pad + i / (values.length - 1) * 300, 110 - (v - min) / range * 100];
	});
	const path = pts.map((pt, i) => `${i === 0 ? "M" : "L"}${pt[0].toFixed(1)},${pt[1].toFixed(1)}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 320 120",
		width: "100%",
		height: "120",
		"aria-label": "Average speed by session",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: path,
			fill: "none",
			stroke: "#F4B740",
			strokeWidth: "1.6"
		}), pts.map((pt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: pt[0].toFixed(1),
			cy: pt[1].toFixed(1),
			r: "2.8",
			fill: "#F4B740"
		}, i))]
	});
}
function PitchOverlay({ bounceDist, totalDist }) {
	const h = 70;
	const pad = 24;
	const frac = bounceDist != null ? Math.max(0, Math.min(1, bounceDist / totalDist)) : null;
	const y = h / 2;
	const releaseX = pad;
	const arrivalX = 296;
	const bounceX = frac != null ? releaseX + frac * 272 : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 320 70",
		width: "100%",
		height: "70",
		"aria-label": "Pitch overlay",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: releaseX,
				y1: y,
				x2: arrivalX,
				y2: y,
				stroke: "#26304366",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: releaseX,
				cy: y,
				r: "5",
				fill: "#2DD4BF"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: releaseX,
				y: 23,
				fontSize: "9",
				fill: "#8B96A8",
				textAnchor: "middle",
				children: "Release"
			}),
			bounceX != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: `M${releaseX},${y} Q${(releaseX + bounceX) / 2},9 ${bounceX},${y}`,
					fill: "none",
					stroke: "#F4B740",
					strokeWidth: "1.6",
					strokeDasharray: "3 3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: bounceX,
					cy: y,
					r: "5",
					fill: "#F4B740"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: bounceX,
					y: 53,
					fontSize: "9",
					fill: "#8B96A8",
					textAnchor: "middle",
					children: "Bounce"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: `M${bounceX},${y} Q${(bounceX + arrivalX) / 2},17 ${arrivalX},${y}`,
					fill: "none",
					stroke: "#FF4B3E",
					strokeWidth: "1.6",
					strokeDasharray: "3 3"
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: `M${releaseX},${y} Q160,11 ${arrivalX},${y}`,
				fill: "none",
				stroke: "#FF4B3E",
				strokeWidth: "1.6",
				strokeDasharray: "3 3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: arrivalX,
				cy: y,
				r: "5",
				fill: "#FF4B3E"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: arrivalX,
				y: 23,
				fontSize: "9",
				fill: "#8B96A8",
				textAnchor: "middle",
				children: "Arrival"
			})
		]
	});
}
function Empty({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "empty",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: title }), children]
	});
}
function StatStrip({ rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "stat-strip",
		children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stat-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "k",
				children: r.k
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "v",
				children: r.v
			})]
		}, r.k))
	});
}
function CardListItem({ title, sub, value, valueLabel, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-list-item",
		onClick,
		onKeyDown: (e) => {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				onClick();
			}
		},
		role: "button",
		tabIndex: 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "cli-title",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "cli-sub",
			children: sub
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cli-val",
			children: [value, valueLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: valueLabel }) : null]
		})]
	});
}
function CoachBox({ insights }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "coach-box",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "coach-summary",
				children: insights.summary
			}),
			insights.observations.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "coach-obs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "dotm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: o })]
			}, o)),
			insights.drills.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "coach-drills",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dl",
					children: "SUGGESTED DRILLS"
				}), insights.drills.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "coach-drill",
					children: ["• ", d]
				}, d))]
			}) : null
		]
	});
}
function SectionLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "section-label",
		children
	});
}
function BackButton({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		className: "btn ghost",
		onClick,
		style: { marginBottom: 14 },
		children: ["← ", label]
	});
}
function ConfidChip({ level }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `confid ${level}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "dot" }),
			"Confidence: ",
			level.toUpperCase()
		]
	});
}
function haptic() {
	try {
		navigator.vibrate?.(18);
	} catch {}
}
function seekTo(vid, t) {
	return new Promise((resolve) => {
		const onSeeked = () => {
			vid.removeEventListener("seeked", onSeeked);
			resolve();
		};
		vid.addEventListener("seeked", onSeeked);
		vid.currentTime = t;
	});
}
function AnalyzeScreen({ forceResultTab, onForceResultConsumed }) {
	const videoRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const captureRef = (0, import_react.useRef)(null);
	const objectUrlRef = (0, import_react.useRef)(null);
	const [tab, setTab] = (0, import_react.useState)("import");
	const [hasVideo, setHasVideo] = (0, import_react.useState)(false);
	const [currentTime, setCurrentTime] = (0, import_react.useState)(0);
	const [duration, setDuration] = (0, import_react.useState)(0);
	const [startMark, setStartMark] = (0, import_react.useState)(null);
	const [endMark, setEndMark] = (0, import_react.useState)(null);
	const [bounceMark, setBounceMark] = (0, import_react.useState)(null);
	const [detectedFps, setDetectedFps] = (0, import_react.useState)(null);
	const [fps, setFps] = (0, import_react.useState)("30");
	const [distance, setDistance] = (0, import_react.useState)("20.12");
	const [bounceDist, setBounceDist] = (0, import_react.useState)("");
	const [angle, setAngle] = (0, import_react.useState)("side");
	const [suggesting, setSuggesting] = (0, import_react.useState)(false);
	const [suggested, setSuggested] = (0, import_react.useState)(null);
	const [lastResult, setLastResult] = (0, import_react.useState)(null);
	const players = useVox((s) => s.players);
	const sessions = useVox((s) => s.sessions);
	const currentSessionId = useVox((s) => s.currentSessionId);
	const addDelivery = useVox((s) => s.addDelivery);
	const openSessionModal = useVox((s) => s.openSessionModal);
	const goto = useVox((s) => s.goto);
	const showToast = useVox((s) => s.showToast);
	(0, import_react.useEffect)(() => {
		if (forceResultTab) {
			setTab("result");
			onForceResultConsumed();
		}
	}, [forceResultTab, onForceResultConsumed]);
	const resetMarks = () => {
		setStartMark(null);
		setEndMark(null);
		setBounceMark(null);
		setSuggested(null);
		setDetectedFps(null);
		setCurrentTime(0);
	};
	const tryDetectFps = (vid) => {
		try {
			const v = vid;
			const track = (v.captureStream?.() ?? v.webkitCaptureStream?.())?.getVideoTracks()[0];
			const settings = track?.getSettings?.();
			if (settings?.frameRate) {
				const rounded = Math.round(settings.frameRate);
				setDetectedFps(rounded);
				setFps(String(rounded));
			}
			track?.stop?.();
		} catch {}
	};
	const loadFile = (file) => {
		if (!file) return;
		if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
		const url = URL.createObjectURL(file);
		objectUrlRef.current = url;
		const vid = videoRef.current;
		if (vid) vid.src = url;
		setHasVideo(true);
		resetMarks();
	};
	(0, import_react.useEffect)(() => {
		return () => {
			if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
		};
	}, []);
	const onMeta = () => {
		const vid = videoRef.current;
		if (!vid) return;
		setDuration(Number.isFinite(vid.duration) ? vid.duration : 0);
		tryDetectFps(vid);
	};
	const onTime = () => {
		const vid = videoRef.current;
		if (!vid) return;
		setCurrentTime(vid.currentTime);
	};
	const stepFrame = (nFrames) => {
		const vid = videoRef.current;
		if (!vid) return;
		const rate = parseFloat(fps) || 30;
		vid.pause();
		vid.currentTime = Math.max(0, Math.min(vid.duration || 0, vid.currentTime + nFrames / rate));
	};
	const markPoint = (which) => {
		const vid = videoRef.current;
		if (!vid) return;
		const t = vid.currentTime;
		if (which === "start") setStartMark(t);
		else if (which === "bounce") setBounceMark(t);
		else setEndMark(t);
		haptic();
	};
	const suggestFrames = async () => {
		const vid = videoRef.current;
		if (!vid || !vid.duration || !Number.isFinite(vid.duration)) return;
		setSuggesting(true);
		const wasPaused = vid.paused;
		vid.pause();
		const cw = 64;
		const ch = 36;
		const canvas = document.createElement("canvas");
		canvas.width = cw;
		canvas.height = ch;
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (!ctx) {
			setSuggesting(false);
			showToast("Motion analysis is not supported on this device.");
			return;
		}
		const sampleCount = 30;
		const frames = [];
		try {
			for (let i = 0; i <= sampleCount; i++) {
				const t = i / sampleCount * vid.duration;
				await seekTo(vid, t);
				ctx.drawImage(vid, 0, 0, cw, ch);
				const data = ctx.getImageData(0, 0, cw, ch).data;
				const gray = /* @__PURE__ */ new Float32Array(2304);
				for (let p = 0; p < 2304; p++) gray[p] = (data[p * 4] + data[p * 4 + 1] + data[p * 4 + 2]) / 3;
				frames.push({
					t,
					gray
				});
			}
			const motion = [];
			for (let i = 1; i < frames.length; i++) {
				let diff = 0;
				const a = frames[i].gray;
				const b = frames[i - 1].gray;
				for (let p = 0; p < a.length; p++) diff += Math.abs(a[p] - b[p]);
				motion.push({
					t: frames[i].t,
					v: diff
				});
			}
			const mid = Math.max(1, Math.floor(motion.length * .5));
			const peak = (arr) => arr.reduce((max, m) => m.v > max.v ? m : max, arr[0]);
			const releaseCandidate = peak(motion.slice(0, mid));
			const arrivalCandidate = peak(motion.slice(mid));
			setSuggested({
				release: releaseCandidate.t,
				arrival: arrivalCandidate.t
			});
		} catch {
			showToast("Motion analysis is not supported on this device — mark frames manually.");
		} finally {
			setSuggesting(false);
			if (!wasPaused) vid.play();
		}
	};
	const jumpToSuggestion = (which) => {
		const vid = videoRef.current;
		if (!suggested || !vid) return;
		vid.currentTime = which === "release" ? suggested.release : suggested.arrival;
	};
	const calculateSpeed = () => {
		if (startMark === null || endMark === null) {
			showToast("Mark both the release frame and the arrival frame first.");
			return;
		}
		const dist = parseFloat(distance);
		const rate = parseFloat(fps);
		if (!dist || dist <= 0) {
			showToast("Enter a valid distance in meters.");
			return;
		}
		if (!rate || rate <= 0) {
			showToast("Enter a valid FPS.");
			return;
		}
		const time = Math.abs(endMark - startMark);
		if (time <= 0) {
			showToast("Start and end frames must differ.");
			return;
		}
		const kmh = dist / time * 3.6;
		const mph = kmhToMph(kmh);
		let confidence = "low";
		if (rate >= 120 && time >= .05) confidence = "high";
		else if (rate >= 60 && time >= .04) confidence = "high";
		else if (rate >= 30 && time >= .03) confidence = "medium";
		else confidence = "low";
		if (kmh > 180 || kmh < 40) confidence = "low";
		const result = {
			kmh,
			mph,
			time,
			distance: dist,
			fps: rate,
			confidence,
			angle,
			bounce: null,
			ts: Date.now()
		};
		if (bounceMark !== null) {
			const bDist = parseFloat(bounceDist);
			result.bounce = bDist > 0 && bounceMark > Math.min(startMark, endMark) && bounceMark < Math.max(startMark, endMark) ? {
				releaseToBounceTime: Math.abs(bounceMark - startMark),
				bounceToArrivalTime: Math.abs(endMark - bounceMark),
				bounceDistance: bDist,
				stumpsDistance: Math.max(0, dist - bDist)
			} : null;
		}
		setLastResult(result);
		setTab("result");
		haptic();
	};
	const saveDelivery = (0, import_react.useCallback)(() => {
		if (!lastResult) return;
		if (!players.length) {
			showToast("Add a player first.");
			goto("players");
			return;
		}
		const sid = currentSessionId && sessions.find((s) => s.id === currentSessionId) ? currentSessionId : null;
		if (sid) {
			const s = sessions.find((x) => x.id === sid);
			addDelivery(sid, {
				...lastResult,
				ts: Date.now()
			});
			showToast(`Delivery saved to "${s?.name ?? "session"}".`);
			return;
		}
		openSessionModal("save-delivery", {
			...lastResult,
			ts: Date.now()
		});
	}, [
		lastResult,
		players.length,
		currentSessionId,
		sessions,
		addDelivery,
		showToast,
		goto,
		openSessionModal
	]);
	const fpsBadge = detectedFps ? `FPS ${detectedFps} (detected)` : "FPS — enter manually";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-analyze",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: "Analyze delivery"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "page-lede",
				children: "Import or record a bowling delivery, mark release, bounce and arrival, and get an estimated speed with a pitch overlay."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tabbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					id: "tabImport",
					className: tab === "import" ? "on" : "",
					onClick: () => setTab("import"),
					children: "Import / Record"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					id: "tabResult",
					className: tab === "result" ? "on" : "",
					onClick: () => setTab("result"),
					children: "Result"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "paneImport",
				style: { display: tab === "import" ? "block" : "none" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "btn-row",
						style: { marginBottom: 14 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "btn block",
							style: { textAlign: "center" },
							children: ["Import video", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: "video/*",
								style: { display: "none" },
								onChange: (e) => loadFile(e.target.files?.[0])
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "btn block",
							style: { textAlign: "center" },
							children: ["Record now", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: captureRef,
								type: "file",
								accept: "video/*",
								capture: "environment",
								style: { display: "none" },
								onChange: (e) => loadFile(e.target.files?.[0])
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "video-wrap",
						id: "videoWrap",
						style: { display: hasVideo ? "block" : "none" },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
								id: "vid",
								ref: videoRef,
								playsInline: true,
								muted: true,
								onLoadedMetadata: onMeta,
								onTimeUpdate: onTime
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "frame-badge",
								id: "fpsBadge",
								children: fpsBadge
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "marker-badge",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: startMark != null ? "set s" : "",
										children: startMark != null ? `S ${startMark.toFixed(2)}s` : "S —"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: bounceMark != null ? "set b" : "",
										children: bounceMark != null ? `B ${bounceMark.toFixed(2)}s` : "B —"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: endMark != null ? "set e" : "",
										children: endMark != null ? `E ${endMark.toFixed(2)}s` : "E —"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						id: "analyzeControls",
						style: { display: hasVideo ? "block" : "none" },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "scrub-row",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									id: "scrub",
									min: 0,
									max: duration || 1,
									value: currentTime,
									step: .01,
									onChange: (e) => {
										const vid = videoRef.current;
										if (vid) vid.currentTime = parseFloat(e.target.value);
									}
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "frame-step",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => stepFrame(-1),
										children: "-1f"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => stepFrame(-5),
										children: "-5f"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "cur",
										children: [currentTime.toFixed(3), "s"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => stepFrame(5),
										children: "+5f"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => stepFrame(1),
										children: "+1f"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mark-row",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mark-btn s",
										onClick: () => markPoint("start"),
										role: "button",
										tabIndex: 0,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "ml",
											children: "RELEASE (start)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mv",
											children: startMark != null ? `${startMark.toFixed(3)}s` : "not set"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mark-btn b",
										onClick: () => markPoint("bounce"),
										role: "button",
										tabIndex: 0,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "ml",
											children: "BOUNCE (optional)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mv",
											children: bounceMark != null ? `${bounceMark.toFixed(3)}s` : "not set"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mark-btn e",
										onClick: () => markPoint("end"),
										role: "button",
										tabIndex: 0,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "ml",
											children: "ARRIVAL (end)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mv",
											children: endMark != null ? `${endMark.toFixed(3)}s` : "not set"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn block",
								style: { marginTop: 10 },
								onClick: () => void suggestFrames(),
								disabled: suggesting,
								children: suggesting ? "Analyzing motion…" : "Suggest frames from motion"
							}),
							suggested ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								id: "suggestBox",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "note",
									children: "Suggested from frame-to-frame motion, not a confirmed ball track — scrub and check before marking."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "btn-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn ghost block",
										onClick: () => jumpToSuggestion("release"),
										children: "Jump to suggested release"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn ghost block",
										onClick: () => jumpToSuggestion("arrival"),
										children: "Jump to suggested arrival"
									})]
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Measurement inputs" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "fl",
									children: "Distance (m) — release point to arrival/reference point"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									inputMode: "decimal",
									placeholder: "e.g. 20.12",
									step: .01,
									value: distance,
									onChange: (e) => setDistance(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "fl",
									children: "Bounce distance (m) — release point to bounce, only if bounce marked"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									inputMode: "decimal",
									placeholder: "e.g. 15.5",
									step: .01,
									value: bounceDist,
									onChange: (e) => setBounceDist(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "calib-grid",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "fl",
										children: "FPS"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										inputMode: "numeric",
										placeholder: "30",
										value: fps,
										onChange: (e) => setFps(e.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "fl",
										children: "Camera angle"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: angle,
										onChange: (e) => setAngle(e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "side",
												children: "Side-on (recommended)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "behind",
												children: "Behind bowler"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "other",
												children: "Other"
											})
										]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn primary block",
								onClick: calculateSpeed,
								children: "Calculate speed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "note",
								children: "Estimated Speed — not a certified radar measurement. Accuracy depends on FPS, camera angle, calibration and ball visibility. Bounce marking is manual — the ball is never auto-tracked or fabricated."
							})
						]
					}),
					!hasVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						id: "importEmpty",
						className: "empty",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "No video loaded" }), "Import a clip from your gallery or record a new delivery to begin."]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "paneResult",
				style: { display: tab === "result" ? "block" : "none" },
				children: !lastResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					title: "No result yet",
					children: "Calculate a delivery in the Import tab first."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: "resultBox",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "speedboard",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfidChip, { level: lastResult.confidence }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sb-num",
									children: fmt(lastResult.kmh, 1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sb-unit",
									children: [
										"km/h \xA0·\xA0 ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmt(lastResult.mph, 1) }),
										" mph"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sb-label",
									children: "ESTIMATED BALL SPEED"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sb-details",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "l",
											children: "Flight time"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "v",
											children: [fmt(lastResult.time, 3), "s"]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "l",
											children: "Distance"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "v",
											children: [fmt(lastResult.distance, 2), "m"]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "l",
											children: "FPS"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "v",
											children: lastResult.fps
										})] })
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `note${lastResult.confidence === "low" ? " warn" : ""}`,
							children: lastResult.confidence === "low" ? "Low confidence — reposition camera, improve lighting, or use a higher-FPS recording for a more reliable estimate." : "Method: Video Frame Analysis (Distance ÷ Flight Time). Estimated speed, not a certified radar measurement."
						}),
						bounceMark !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							id: "bounceBox",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Bounce / pitch analysis" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatStrip, { rows: [
									{
										k: "Release → bounce time",
										v: lastResult.bounce ? `${fmt(lastResult.bounce.releaseToBounceTime, 3)}s` : "—"
									},
									{
										k: "Bounce → arrival time",
										v: lastResult.bounce ? `${fmt(lastResult.bounce.bounceToArrivalTime, 3)}s` : "—"
									},
									{
										k: "Bounce distance",
										v: lastResult.bounce ? `${fmt(lastResult.bounce.bounceDistance, 2)}m` : "enter bounce distance"
									},
									{
										k: "Bounce → stumps (est.)",
										v: lastResult.bounce ? `${fmt(lastResult.bounce.stumpsDistance, 2)}m` : "—"
									}
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pitch-box",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "l",
										children: "Pitch overlay — release / bounce / arrival, to scale on measured distance"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PitchOverlay, {
										bounceDist: lastResult.bounce?.bounceDistance ?? null,
										totalDist: lastResult.distance
									})]
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "btn-row",
							style: { marginTop: 14 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn teal block",
								onClick: saveDelivery,
								children: "Save to session"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn ghost block",
								onClick: () => setTab("import"),
								children: "Re-mark frames"
							})]
						})
					]
				})
			})
		]
	});
}
function sessionStats(s) {
	const speeds = s.deliveries.map((d) => d.kmh).filter((v) => v != null);
	if (!speeds.length) return {
		fastest: null,
		slowest: null,
		avg: null,
		median: null,
		valid: 0,
		low: 0,
		consistency: null
	};
	const sorted = [...speeds].sort((a, b) => a - b);
	const avg = speeds.reduce((a, b) => a + b, 0) / speeds.length;
	const median = sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2;
	const variance = speeds.reduce((a, b) => a + (b - avg) * (b - avg), 0) / speeds.length;
	const consistency = avg > 0 ? Math.max(0, 100 - Math.sqrt(variance) / avg * 100) : 0;
	return {
		fastest: Math.max(...speeds),
		slowest: Math.min(...speeds),
		avg,
		median,
		valid: speeds.length,
		low: s.deliveries.filter((d) => d.confidence === "low").length,
		consistency
	};
}
/**
* Deterministic, on-device analysis of the bowler's own recorded measurements.
* Every line is derived from real saved deliveries — nothing is invented.
*/
function generateCoachInsights(deliveries) {
	const valid = deliveries.filter((d) => d.kmh != null);
	if (valid.length < 3) return {
		summary: "Record at least 3 deliveries in this session for the coach to analyze pace and consistency.",
		observations: [],
		drills: []
	};
	const speeds = valid.map((d) => d.kmh);
	const min = Math.min(...speeds);
	const max = Math.max(...speeds);
	const avg = speeds.reduce((a, b) => a + b, 0) / speeds.length;
	const sd = Math.sqrt(speeds.reduce((a, b) => a + (b - avg) * (b - avg), 0) / speeds.length);
	const consistency = avg > 0 ? Math.max(0, 100 - sd / avg * 100) : 0;
	const lowCount = valid.filter((d) => d.confidence === "low").length;
	const lowRatio = lowCount / valid.length;
	const half = Math.floor(speeds.length / 2);
	const firstHalf = speeds.slice(0, half || 1);
	const secondHalf = speeds.slice(speeds.length - (half || 1));
	const drop = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length - secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length;
	const summary = `Recorded ${valid.length} deliveries ranging from ${fmt(min, 1)}–${fmt(max, 1)} km/h, averaging ${fmt(avg, 1)} km/h at ${fmt(consistency, 0)}% consistency.`;
	const observations = [];
	const drills = [];
	if (Math.abs(drop) >= 2) {
		if (drop > 0) {
			observations.push(`Your final deliveries averaged ${fmt(drop, 1)} km/h slower than your first ones — a fatigue pattern across the session.`);
			drills.push("Fatigue management — split long spells into shorter high-intensity sets with full recovery, and re-check pace in the back half of practice.");
		} else observations.push(`Your later deliveries were ${fmt(Math.abs(drop), 1)} km/h faster on average than your first ones — pace built through the session.`);
	} else observations.push("Pace held steady from the start of the session to the end — no meaningful fatigue drop detected.");
	if (consistency >= 90) observations.push("Delivery-to-delivery consistency is excellent, within a tight speed band.");
	else if (consistency >= 75) {
		observations.push("Consistency is solid, with some natural variation delivery to delivery.");
		drills.push("Run-up consistency — bowl to a fixed run-up mark and focus on repeating release timing each delivery.");
	} else {
		observations.push(`Consistency is lower than typical (${fmt(consistency, 0)}%) — speed varied noticeably between deliveries.`);
		drills.push("Run-up consistency — bowl to a fixed run-up mark and focus on repeating release timing each delivery.");
		drills.push("Rhythm drill — bowl 6-ball overs at 70% effort focusing purely on a repeatable action before building back to full pace.");
	}
	if (lowRatio > .2) {
		observations.push(`${lowCount} of ${valid.length} deliveries were low-confidence readings — camera setup is limiting measurement reliability.`);
		drills.push("Recording setup — use a side-on angle, 60fps or higher, even lighting and a stable phone position for more reliable readings.");
	}
	if (!drills.length) drills.push("No corrective drills flagged from this data — maintain the current run-up and recording setup.");
	return {
		summary,
		observations,
		drills
	};
}
function IconHome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 11.5 12 4l8 7.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 10v9h12v-9" })]
	});
}
function IconList() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01" })
	});
}
function IconPlay() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "9"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 8.5v7l6-3.5z",
			fill: "currentColor",
			stroke: "none"
		})]
	});
}
function IconUser() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "8",
			r: "3.4"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6" })]
	});
}
function IconDots() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "5",
				cy: "12",
				r: "1.4",
				fill: "currentColor",
				stroke: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "1.4",
				fill: "currentColor",
				stroke: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19",
				cy: "12",
				r: "1.4",
				fill: "currentColor",
				stroke: "none"
			})
		]
	});
}
function IconBolt() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		width: "20",
		height: "20",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M13 3 5 14h6l-1 7 8-11h-6z" })
	});
}
function HomeScreen() {
	const sessions = useVox((s) => s.sessions);
	const goto = useVox((s) => s.goto);
	const all = sessions.flatMap((s) => s.deliveries.map((d) => ({
		...d,
		sessionName: s.name
	})));
	const last = [...all].sort((a, b) => b.ts - a.ts)[0];
	const speeds = all.map((d) => d.kmh);
	const fastest = speeds.length ? Math.max(...speeds) : null;
	const avg = speeds.length ? speeds.reduce((a, b) => a + b, 0) / speeds.length : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-home",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hero",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hero-label",
						children: "Last recorded delivery"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hero-num",
						children: last ? fmt(last.kmh, 1) : "—"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hero-unit",
						children: "km/h"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-foot",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hero-meta",
							children: last ? `${last.sessionName} · ${timeAgo(last.ts)}` : "No deliveries yet"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "hero-cta",
							onClick: () => goto("analyze"),
							children: "Analyze a delivery"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatStrip, { rows: [
				{
					k: "Fastest recorded",
					v: `${fmt(fastest, 1)} km/h`
				},
				{
					k: "Average speed",
					v: `${fmt(avg, 1)} km/h`
				},
				{
					k: "Total deliveries",
					v: String(all.length)
				},
				{
					k: "Sessions logged",
					v: String(sessions.length)
				}
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Quick actions" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "quick-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "quick-btn",
					onClick: () => {
						goto("analyze");
						window.dispatchEvent(new CustomEvent("voxvelo:speedboard"));
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "qi",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBolt, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "qt",
							children: "Speed Board"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "qs",
							children: "Live single-delivery readout"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "quick-btn",
					onClick: () => goto("sessions"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "qi",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconList, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "qt",
							children: "My Sessions"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "qs",
							children: "Review past bowling sessions"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Recent sessions" }),
			!sessions.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "No sessions yet",
				children: "Analyze your first delivery to start a session."
			}) : sessions.slice(0, 3).map((s) => {
				const st = sessionStats(s);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardListItem, {
					title: s.name,
					sub: `${s.deliveries.length} deliveries · ${timeAgo(s.createdAt)}`,
					value: fmt(st.avg, 1),
					valueLabel: "avg km/h",
					onClick: () => goto("session-detail", s.id)
				}, s.id);
			})
		]
	});
}
function PlayerModal() {
	const open = useVox((s) => s.playerModalOpen);
	const close = useVox((s) => s.closePlayerModal);
	const addPlayer = useVox((s) => s.addPlayer);
	const showToast = useVox((s) => s.showToast);
	const [name, setName] = (0, import_react.useState)("");
	const [hand, setHand] = (0, import_react.useState)("Right-handed");
	const [style, setStyle] = (0, import_react.useState)("Fast");
	const [team, setTeam] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (open) {
			setName("");
			setTeam("");
			setHand("Right-handed");
			setStyle("Fast");
		}
	}, [open]);
	const save = () => {
		const trimmed = name.trim();
		if (!trimmed) {
			showToast("Enter a player name.");
			return;
		}
		addPlayer({
			name: trimmed,
			hand,
			style,
			team: team.trim()
		});
		showToast("Player saved.");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `modal-bg${open ? " on" : ""}`,
		onClick: (e) => {
			if (e.target === e.currentTarget) close();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "modal",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Add player" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "fl",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "Player name",
						value: name,
						onChange: (e) => setName(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "calib-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "fl",
							children: "Handedness"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: hand,
							onChange: (e) => setHand(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Right-handed" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Left-handed" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "fl",
							children: "Style"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: style,
							onChange: (e) => setStyle(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Fast" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Medium" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Spin" })
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "fl",
						children: "Team / Academy (optional)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "Optional",
						value: team,
						onChange: (e) => setTeam(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "btn-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn ghost block",
						onClick: close,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary block",
						onClick: save,
						children: "Save player"
					})]
				})
			]
		})
	});
}
function SessionModal() {
	const open = useVox((s) => s.sessionModalOpen);
	const mode = useVox((s) => s.sessionModalMode);
	const close = useVox((s) => s.closeSessionModal);
	const players = useVox((s) => s.players);
	const activePlayerId = useVox((s) => s.activePlayerId);
	const addSession = useVox((s) => s.addSession);
	const savePendingDelivery = useVox((s) => s.savePendingDelivery);
	const showToast = useVox((s) => s.showToast);
	const [name, setName] = (0, import_react.useState)("");
	const [playerId, setPlayerId] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (open) {
			setName(`Session ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`);
			setPlayerId(activePlayerId || players[0]?.id || "");
		}
	}, [
		open,
		activePlayerId,
		players
	]);
	const confirm = () => {
		if (!playerId) {
			showToast("Add a player first.");
			return;
		}
		const sessionName = name.trim() || "Session";
		if (mode === "save-delivery") {
			const s = savePendingDelivery(sessionName, playerId);
			showToast(`Session "${s.name}" created and delivery saved.`);
		} else {
			const s = addSession(sessionName, playerId);
			showToast(`Session "${s.name}" created.`);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `modal-bg${open ? " on" : ""}`,
		onClick: (e) => {
			if (e.target === e.currentTarget) close();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "modal",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Session details" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "fl",
						children: "Session name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "e.g. Morning Nets",
						value: name,
						onChange: (e) => setName(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "fl",
						children: "Player"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: playerId,
						onChange: (e) => setPlayerId(e.target.value),
						children: players.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.name
						}, p.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "btn-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn ghost block",
						onClick: close,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary block",
						onClick: confirm,
						children: mode === "save-delivery" ? "Save delivery" : "Create session"
					})]
				})
			]
		})
	});
}
function ConfirmModal() {
	const confirm = useVox((s) => s.confirm);
	const close = useVox((s) => s.closeConfirm);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `modal-bg${confirm ? " on" : ""}`,
		onClick: (e) => {
			if (e.target === e.currentTarget) close();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "modal",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: confirm?.title ?? "" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "page-lede",
					style: { marginBottom: 18 },
					children: confirm?.message ?? ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "btn-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn ghost block",
						onClick: close,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn primary block",
						onClick: () => {
							confirm?.onConfirm();
							close();
						},
						children: confirm?.confirmLabel ?? "Confirm"
					})]
				})
			]
		})
	});
}
function Toast() {
	const toast = useVox((s) => s.toast);
	if (!toast) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "vv-toast",
		role: "status",
		children: toast
	});
}
function MoreScreen() {
	const exportData = useVox((s) => s.exportData);
	const askConfirm = useVox((s) => s.askConfirm);
	const clearAllData = useVox((s) => s.clearAllData);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-more",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: "More"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "page-lede",
				children: "VoxVelo Cricket — your cricket performance lab."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Coming soon" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stat-strip",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "k",
							children: "Automatic ball tracking (needs a CV/pose model)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "soon",
							children: "Phase 3"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "k",
							children: "Advanced biomechanics (needs a pose model)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "soon",
							children: "Phase 3"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stat-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "k",
							children: "Cloud backup & billing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "soon",
							children: "Future"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Data" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn block",
				style: { marginBottom: 10 },
				onClick: () => void exportData(),
				children: "Export data (JSON)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn block",
				onClick: () => askConfirm({
					title: "Clear all local data",
					message: "This deletes all players, sessions and deliveries stored on this device. Continue?",
					confirmLabel: "Clear data",
					onConfirm: clearAllData
				}),
				children: "Clear all local data"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "note",
				style: { marginTop: 16 },
				children: "All videos and measurements stay on this device by default. Nothing is uploaded unless you explicitly enable cloud AI analysis in a future update. The AI Coach runs entirely on your recorded measurements, on-device — it never invents numbers."
			})
		]
	});
}
function PlayersScreen() {
	const players = useVox((s) => s.players);
	const sessions = useVox((s) => s.sessions);
	const activePlayerId = useVox((s) => s.activePlayerId);
	const goto = useVox((s) => s.goto);
	const openPlayerModal = useVox((s) => s.openPlayerModal);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-players",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: "Players"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "page-lede",
				children: "Create a profile for each bowler you track."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn primary block",
				onClick: openPlayerModal,
				children: "Add player"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "btn-row",
				style: { marginTop: 10 },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn block",
					onClick: () => goto("team-dashboard"),
					children: "Team / academy view"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn block",
					onClick: () => goto("compare"),
					children: "Compare"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "All players" }),
			!players.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "No players yet",
				children: "Add a player to start tracking their sessions."
			}) : players.map((p) => {
				const speeds = sessions.filter((s) => s.playerId === p.id).flatMap((s) => s.deliveries.map((d) => d.kmh));
				const best = speeds.length ? Math.max(...speeds) : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardListItem, {
					title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						p.name,
						" ",
						p.id === activePlayerId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["\xA0·\xA0", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: {
								color: "var(--teal)",
								fontSize: 11
							},
							children: "active"
						})] }) : null
					] }),
					sub: `${p.style} · ${p.hand}${p.team ? ` · ${p.team}` : ""}`,
					value: best ? fmt(best, 1) : "—",
					valueLabel: "best km/h",
					onClick: () => goto("player-detail", p.id)
				}, p.id);
			})
		]
	});
}
function PlayerDetailScreen() {
	const id = useVox((s) => s.screenPayload);
	const players = useVox((s) => s.players);
	const sessions = useVox((s) => s.sessions);
	const goto = useVox((s) => s.goto);
	const setActivePlayer = useVox((s) => s.setActivePlayer);
	const showToast = useVox((s) => s.showToast);
	const p = players.find((x) => x.id === id);
	if (!p) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
			label: "Players",
			onClick: () => goto("players")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { title: "Player not found" })]
	});
	const playerSessions = sessions.filter((s) => s.playerId === p.id).slice().sort((a, b) => a.createdAt - b.createdAt);
	const allDeliveries = playerSessions.flatMap((s) => s.deliveries);
	const speeds = allDeliveries.map((d) => d.kmh);
	const best = speeds.length ? Math.max(...speeds) : null;
	const avg = speeds.length ? speeds.reduce((a, b) => a + b, 0) / speeds.length : null;
	const sessionAvgs = playerSessions.map((s) => sessionStats(s).avg).filter((v) => v != null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-player-detail",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
				label: "Players",
				onClick: () => goto("players")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: p.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "page-lede",
				children: [
					p.style,
					" · ",
					p.hand,
					p.team ? ` · ${p.team}` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatStrip, { rows: [
				{
					k: "Best delivery",
					v: `${fmt(best, 1)} km/h`
				},
				{
					k: "Overall average",
					v: `${fmt(avg, 1)} km/h`
				},
				{
					k: "Sessions",
					v: String(playerSessions.length)
				},
				{
					k: "Total deliveries",
					v: String(allDeliveries.length)
				}
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Performance trend — average speed by session" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "chart-box",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendChart, { values: sessionAvgs })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "AI Cricket Coach — career summary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoachBox, { insights: generateCoachInsights(allDeliveries) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Sessions" }),
			playerSessions.length ? [...playerSessions].reverse().map((s) => {
				const st = sessionStats(s);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardListItem, {
					title: s.name,
					sub: `${s.deliveries.length} deliveries · ${timeAgo(s.createdAt)}`,
					value: fmt(st.avg, 1),
					valueLabel: "avg km/h",
					onClick: () => goto("session-detail", s.id)
				}, s.id);
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { title: "No sessions for this player yet." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn block",
				style: { marginTop: 16 },
				onClick: () => {
					setActivePlayer(p.id);
					showToast(`${p.name} is now the active player.`);
				},
				children: "Set as active player"
			})
		]
	});
}
function TeamDashboardScreen() {
	const players = useVox((s) => s.players);
	const sessions = useVox((s) => s.sessions);
	const goto = useVox((s) => s.goto);
	const groups = {};
	players.forEach((p) => {
		const key = p.team && p.team.trim() ? p.team.trim() : "Unassigned";
		(groups[key] = groups[key] || []).push(p);
	});
	const keys = Object.keys(groups).sort((a, b) => a === "Unassigned" ? 1 : b === "Unassigned" ? -1 : a.localeCompare(b));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-team-dashboard",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
				label: "Players",
				onClick: () => goto("players")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: "Team & academy view"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "page-lede",
				children: "Players grouped by the team/academy on their profile, with squad-level speed stats."
			}),
			!keys.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "No players yet",
				children: "Add players with a team/academy to see squad stats here."
			}) : keys.map((k) => {
				const roster = groups[k];
				const speeds = roster.flatMap((p) => sessions.filter((s) => s.playerId === p.id).flatMap((s) => s.deliveries.map((d) => d.kmh)));
				const fastest = speeds.length ? Math.max(...speeds) : null;
				const avg = speeds.length ? speeds.reduce((a, b) => a + b, 0) / speeds.length : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "team-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", { children: k }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ts",
							children: [
								roster.length,
								" player",
								roster.length === 1 ? "" : "s",
								" · fastest ",
								fmt(fastest, 1),
								" km/h · avg ",
								fmt(avg, 1),
								" km/h"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "team-roster",
							children: roster.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								onClick: () => goto("player-detail", p.id),
								style: { cursor: "pointer" },
								role: "button",
								tabIndex: 0,
								children: p.name
							}, p.id))
						})
					]
				}, k);
			})
		]
	});
}
function CompareScreen() {
	const players = useVox((s) => s.players);
	const sessions = useVox((s) => s.sessions);
	const goto = useVox((s) => s.goto);
	const [mode, setMode] = (0, import_react.useState)("players");
	const items = mode === "players" ? players : sessions;
	const [idA, setIdA] = (0, import_react.useState)(items[0]?.id ?? "");
	const [idB, setIdB] = (0, import_react.useState)(items[1]?.id ?? items[0]?.id ?? "");
	const switchMode = (next) => {
		setMode(next);
		const nextItems = next === "players" ? players : sessions;
		setIdA(nextItems[0]?.id ?? "");
		setIdB(nextItems[1]?.id ?? nextItems[0]?.id ?? "");
	};
	const stA = (0, import_react.useMemo)(() => {
		if (mode === "players") return sessionStats({ deliveries: sessions.filter((s) => s.playerId === idA).flatMap((s) => s.deliveries) });
		const s = sessions.find((x) => x.id === idA);
		return s ? sessionStats(s) : sessionStats({ deliveries: [] });
	}, [
		mode,
		idA,
		sessions
	]);
	const stB = (0, import_react.useMemo)(() => {
		if (mode === "players") return sessionStats({ deliveries: sessions.filter((s) => s.playerId === idB).flatMap((s) => s.deliveries) });
		const s = sessions.find((x) => x.id === idB);
		return s ? sessionStats(s) : sessionStats({ deliveries: [] });
	}, [
		mode,
		idB,
		sessions
	]);
	const nameA = items.find((it) => it.id === idA)?.name ?? "—";
	const nameB = items.find((it) => it.id === idB)?.name ?? "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-compare",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
				label: "Players",
				onClick: () => goto("players")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: "Compare"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "page-lede",
				children: "Player vs player, or session vs session."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "seg",
				style: { marginBottom: 16 },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: mode === "players" ? "on" : "",
					onClick: () => switchMode("players"),
					children: "Players"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: mode === "sessions" ? "on" : "",
					onClick: () => switchMode("sessions"),
					children: "Sessions"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "calib-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "fl",
						children: "A"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: idA,
						onChange: (e) => setIdA(e.target.value),
						children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: it.id,
							children: it.name
						}, it.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "fl",
						children: "B"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: idB,
						onChange: (e) => setIdB(e.target.value),
						children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: it.id,
							children: it.name
						}, it.id))
					})]
				})]
			}),
			items.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { title: `Add at least two ${mode} with saved deliveries to compare.` }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "chart-box",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cmp-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: nameA }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "cmp-label",
							children: "METRIC"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							style: { textAlign: "right" },
							children: nameB
						})
					]
				}), [
					[
						"Fastest",
						"fastest",
						"km/h"
					],
					[
						"Average",
						"avg",
						"km/h"
					],
					[
						"Consistency",
						"consistency",
						"%"
					],
					[
						"Deliveries",
						"valid",
						""
					]
				].map(([label, key, unit]) => {
					const a = stA[key];
					const b = stB[key];
					const aWin = a != null && b != null && a > b;
					const bWin = a != null && b != null && b > a;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "cmp-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `cv${aWin ? " win" : ""}`,
								children: [a != null ? fmt(a, key === "valid" ? 0 : 1) : "—", unit && a != null ? ` ${unit}` : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "cmp-label",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `cv${bWin ? " win" : ""}`,
								children: [b != null ? fmt(b, key === "valid" ? 0 : 1) : "—", unit && b != null ? ` ${unit}` : ""]
							})
						]
					}, label);
				})]
			})
		]
	});
}
function SessionsScreen() {
	const sessions = useVox((s) => s.sessions);
	const players = useVox((s) => s.players);
	const goto = useVox((s) => s.goto);
	const openSessionModal = useVox((s) => s.openSessionModal);
	const showToast = useVox((s) => s.showToast);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-sessions",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: "Sessions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "page-lede",
				children: "Every bowling session you've recorded, with speed and consistency at a glance."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn primary block",
				onClick: () => {
					if (!players.length) {
						showToast("Add a player first, then start a session.");
						goto("players");
						return;
					}
					openSessionModal("create");
				},
				children: "Start new session"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "History" }),
			!sessions.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "No sessions yet",
				children: "Start a session and save a few deliveries to see them here."
			}) : sessions.map((s) => {
				const st = sessionStats(s);
				const player = players.find((p) => p.id === s.playerId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardListItem, {
					title: s.name,
					sub: `${player ? player.name : "—"} · ${s.deliveries.length} deliveries · ${timeAgo(s.createdAt)}`,
					value: st.avg ? fmt(st.avg, 1) : "—",
					valueLabel: "avg km/h",
					onClick: () => goto("session-detail", s.id)
				}, s.id);
			})
		]
	});
}
function SessionDetailScreen() {
	const id = useVox((s) => s.screenPayload);
	const sessions = useVox((s) => s.sessions);
	const players = useVox((s) => s.players);
	const goto = useVox((s) => s.goto);
	const s = sessions.find((x) => x.id === id);
	if (!s) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
			label: "Sessions",
			onClick: () => goto("sessions")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "Session not found",
			children: "It may have been cleared from this device."
		})]
	});
	const st = sessionStats(s);
	const player = players.find((p) => p.id === s.playerId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "screen active",
		id: "screen-session-detail",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
				label: "Sessions",
				onClick: () => goto("sessions")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: s.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "page-lede",
				children: [
					player ? player.name : "—",
					" · ",
					new Date(s.createdAt).toLocaleString()
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatStrip, { rows: [
				{
					k: "Fastest",
					v: `${fmt(st.fastest, 1)} km/h`
				},
				{
					k: "Slowest",
					v: `${fmt(st.slowest, 1)} km/h`
				},
				{
					k: "Average",
					v: `${fmt(st.avg, 1)} km/h`
				},
				{
					k: "Median",
					v: `${fmt(st.median, 1)} km/h`
				},
				{
					k: "Consistency",
					v: st.consistency ? `${fmt(st.consistency, 0)}%` : "—"
				},
				{
					k: "Valid / low-confidence",
					v: `${st.valid} / ${st.low}`
				}
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Speed by delivery" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "chart-box",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeedChart, { deliveries: s.deliveries })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Distribution & session progress" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "chart-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chart-box",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "chart-mini-label",
						children: "Speed distribution"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistogramChart, { deliveries: s.deliveries })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chart-box",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "chart-mini-label",
						children: "Progress (fatigue trend)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressChart, { deliveries: s.deliveries })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Deliveries" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "chart-box",
				id: "sdDeliveries",
				children: s.deliveries.length ? s.deliveries.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "deliv-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "n",
							children: ["#", i + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							new Date(d.ts).toLocaleTimeString(),
							" · ",
							d.confidence
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "s",
							children: [fmt(d.kmh, 1), " km/h"]
						})
					]
				}, `${d.ts}-${i}`)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { title: "No deliveries saved yet" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "AI Cricket Coach" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoachBox, { insights: generateCoachInsights(s.deliveries) })
		]
	});
}
function navActive(screen, tab) {
	if (tab === "sessions") return screen === "sessions" || screen === "session-detail";
	if (tab === "players") return screen === "players" || screen === "player-detail" || screen === "team-dashboard" || screen === "compare";
	return screen === tab;
}
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "shell",
		className: "vv-boot",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "brand",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "brand-mark" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "brand-name",
				children: "VoxVelo"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "brand-sub",
				children: "Measure. Analyze. Improve."
			})] })]
		})
	});
}
function VoxVeloApp() {
	const hydrated = useVox((s) => s.hydrated);
	const hydrate = useVox((s) => s.hydrate);
	const screen = useVox((s) => s.screen);
	const goto = useVox((s) => s.goto);
	const players = useVox((s) => s.players);
	const activePlayerId = useVox((s) => s.activePlayerId);
	const [forceResult, setForceResult] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const onBoard = () => setForceResult(true);
		window.addEventListener("voxvelo:speedboard", onBoard);
		return () => window.removeEventListener("voxvelo:speedboard", onBoard);
	}, []);
	const consumeForce = (0, import_react.useCallback)(() => setForceResult(false), []);
	const active = players.find((p) => p.id === activePlayerId);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "topbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "brand-mark" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "brand-name",
						children: "VoxVelo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "brand-sub",
						children: "Measure. Analyze. Improve."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "player-chip",
					id: "playerChipBtn",
					onClick: () => goto("players"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "dot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						id: "playerChipName",
						children: active ? active.name : "No player"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				screen === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {}) : null,
				screen === "sessions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionsScreen, {}) : null,
				screen === "session-detail" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionDetailScreen, {}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: { display: screen === "analyze" ? "block" : "none" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyzeScreen, {
						forceResultTab: forceResult,
						onForceResultConsumed: consumeForce
					})
				}),
				screen === "players" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayersScreen, {}) : null,
				screen === "player-detail" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerDetailScreen, {}) : null,
				screen === "team-dashboard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamDashboardScreen, {}) : null,
				screen === "compare" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareScreen, {}) : null,
				screen === "more" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreScreen, {}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				id: "navbar",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `nav-btn${navActive(screen, "home") ? " active" : ""}`,
						onClick: () => goto("home"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconHome, {}), "Home"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `nav-btn${navActive(screen, "sessions") ? " active" : ""}`,
						onClick: () => goto("sessions"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconList, {}), "Sessions"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `nav-btn${navActive(screen, "analyze") ? " active" : ""}`,
						onClick: () => goto("analyze"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconPlay, {}), "Analyze"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `nav-btn${navActive(screen, "players") ? " active" : ""}`,
						onClick: () => goto("players"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconUser, {}), "Players"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `nav-btn${navActive(screen, "more") ? " active" : ""}`,
						onClick: () => goto("more"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconDots, {}), "More"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerModal, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionModal, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmModal, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toast, {})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoxVeloApp, {});
}
//#endregion
export { Home as component };
