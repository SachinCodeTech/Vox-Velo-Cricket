//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B_smMT4h.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CKxFNwrC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CKxFNwrC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-4wrxJHMh.js"]
	}
} });
//#endregion
export { tsrStartManifest };
