import { createFileRoute } from "@tanstack/react-router";
import { VoxVeloApp } from "@/components/voxvelo/App";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <VoxVeloApp />;
}
