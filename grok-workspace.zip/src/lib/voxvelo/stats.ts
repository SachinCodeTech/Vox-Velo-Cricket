import type { CoachInsights, Delivery, Session, SessionStats } from "./types";
import { fmt } from "./format";

export function sessionStats(s: { deliveries: Delivery[] }): SessionStats {
  const speeds = s.deliveries.map((d) => d.kmh).filter((v) => v != null);
  if (!speeds.length) {
    return {
      fastest: null,
      slowest: null,
      avg: null,
      median: null,
      valid: 0,
      low: 0,
      consistency: null,
    };
  }
  const sorted = [...speeds].sort((a, b) => a - b);
  const avg = speeds.reduce((a, b) => a + b, 0) / speeds.length;
  const median =
    sorted.length % 2
      ? sorted[(sorted.length - 1) / 2]!
      : (sorted[sorted.length / 2 - 1]! + sorted[sorted.length / 2]!) / 2;
  const variance =
    speeds.reduce((a, b) => a + (b - avg) * (b - avg), 0) / speeds.length;
  const sd = Math.sqrt(variance);
  const consistency = avg > 0 ? Math.max(0, 100 - (sd / avg) * 100) : 0;
  return {
    fastest: Math.max(...speeds),
    slowest: Math.min(...speeds),
    avg,
    median,
    valid: speeds.length,
    low: s.deliveries.filter((d) => d.confidence === "low").length,
    consistency,
  };
}

/**
 * Deterministic, on-device analysis of the bowler's own recorded measurements.
 * Every line is derived from real saved deliveries — nothing is invented.
 */
export function generateCoachInsights(deliveries: Delivery[]): CoachInsights {
  const valid = deliveries.filter((d) => d.kmh != null);
  if (valid.length < 3) {
    return {
      summary:
        "Record at least 3 deliveries in this session for the coach to analyze pace and consistency.",
      observations: [],
      drills: [],
    };
  }
  const speeds = valid.map((d) => d.kmh);
  const min = Math.min(...speeds);
  const max = Math.max(...speeds);
  const avg = speeds.reduce((a, b) => a + b, 0) / speeds.length;
  const sd = Math.sqrt(
    speeds.reduce((a, b) => a + (b - avg) * (b - avg), 0) / speeds.length,
  );
  const consistency = avg > 0 ? Math.max(0, 100 - (sd / avg) * 100) : 0;
  const lowCount = valid.filter((d) => d.confidence === "low").length;
  const lowRatio = lowCount / valid.length;

  const half = Math.floor(speeds.length / 2);
  const firstHalf = speeds.slice(0, half || 1);
  const secondHalf = speeds.slice(speeds.length - (half || 1));
  const firstAvg = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length;
  const secondAvg = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length;
  const drop = firstAvg - secondAvg;

  const summary = `Recorded ${valid.length} deliveries ranging from ${fmt(min, 1)}–${fmt(max, 1)} km/h, averaging ${fmt(avg, 1)} km/h at ${fmt(consistency, 0)}% consistency.`;

  const observations: string[] = [];
  const drills: string[] = [];

  if (Math.abs(drop) >= 2) {
    if (drop > 0) {
      observations.push(
        `Your final deliveries averaged ${fmt(drop, 1)} km/h slower than your first ones — a fatigue pattern across the session.`,
      );
      drills.push(
        "Fatigue management — split long spells into shorter high-intensity sets with full recovery, and re-check pace in the back half of practice.",
      );
    } else {
      observations.push(
        `Your later deliveries were ${fmt(Math.abs(drop), 1)} km/h faster on average than your first ones — pace built through the session.`,
      );
    }
  } else {
    observations.push(
      "Pace held steady from the start of the session to the end — no meaningful fatigue drop detected.",
    );
  }

  if (consistency >= 90) {
    observations.push(
      "Delivery-to-delivery consistency is excellent, within a tight speed band.",
    );
  } else if (consistency >= 75) {
    observations.push(
      "Consistency is solid, with some natural variation delivery to delivery.",
    );
    drills.push(
      "Run-up consistency — bowl to a fixed run-up mark and focus on repeating release timing each delivery.",
    );
  } else {
    observations.push(
      `Consistency is lower than typical (${fmt(consistency, 0)}%) — speed varied noticeably between deliveries.`,
    );
    drills.push(
      "Run-up consistency — bowl to a fixed run-up mark and focus on repeating release timing each delivery.",
    );
    drills.push(
      "Rhythm drill — bowl 6-ball overs at 70% effort focusing purely on a repeatable action before building back to full pace.",
    );
  }

  if (lowRatio > 0.2) {
    observations.push(
      `${lowCount} of ${valid.length} deliveries were low-confidence readings — camera setup is limiting measurement reliability.`,
    );
    drills.push(
      "Recording setup — use a side-on angle, 60fps or higher, even lighting and a stable phone position for more reliable readings.",
    );
  }

  if (!drills.length) {
    drills.push(
      "No corrective drills flagged from this data — maintain the current run-up and recording setup.",
    );
  }

  return { summary, observations, drills };
}

export function allDeliveriesForPlayer(
  sessions: Session[],
  playerId: string,
): Delivery[] {
  return sessions
    .filter((s) => s.playerId === playerId)
    .flatMap((s) => s.deliveries);
}
