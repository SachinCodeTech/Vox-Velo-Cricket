import { EMPTY_DB, type DB } from "./types";
import { makeSeed } from "./seed";

export const DB_KEY = "voxvelo_v1";

function isDb(value: unknown): value is DB {
  if (!value || typeof value !== "object") return false;
  const v = value as DB;
  return Array.isArray(v.players) && Array.isArray(v.sessions);
}

export function loadDB(): DB {
  if (typeof window === "undefined") return EMPTY_DB;
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      const parsed: unknown = JSON.parse(raw);
      if (isDb(parsed)) return parsed;
    }
  } catch {
    /* corrupted — seed a fresh lab */
  }
  const seeded = makeSeed();
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(seeded));
  } catch {
    /* quota */
  }
  return seeded;
}

export function saveDB(db: DB): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
  } catch {
    /* quota */
  }
}

export async function exportDB(db: DB): Promise<"shared" | "downloaded"> {
  const json = JSON.stringify(db, null, 2);
  const filename = `voxvelo-export-${Date.now()}.json`;
  const blob = new Blob([json], { type: "application/json" });
  const file = new File([blob], filename, { type: "application/json" });

  const nav = navigator as Navigator & {
    canShare?: (data: ShareData) => boolean;
  };
  if (nav.share && nav.canShare?.({ files: [file] })) {
    try {
      await nav.share({ files: [file], title: "VoxVelo export" });
      return "shared";
    } catch (err) {
      if ((err as { name?: string }).name === "AbortError") return "shared";
    }
  }

  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
  return "downloaded";
}
