import type { DB, Delivery, Player, Session } from "./types";

const DAY = 86_400_000;

function del(
  kmh: number,
  ts: number,
  confidence: Delivery["confidence"] = "high",
  extras: Partial<Delivery> = {},
): Delivery {
  const time = 20.12 / (kmh / 3.6);
  return {
    kmh,
    mph: kmh * 0.621371,
    time,
    distance: 20.12,
    fps: 60,
    confidence,
    angle: "side",
    bounce: null,
    ts,
    ...extras,
  };
}

export function makeSeed(now = Date.now()): DB {
  const players: Player[] = [
    {
      id: "p_arjun",
      name: "Arjun Mehta",
      hand: "Right-handed",
      style: "Fast",
      team: "VoxVelo Academy",
      createdAt: now - 20 * DAY,
    },
    {
      id: "p_priya",
      name: "Priya Sharma",
      hand: "Right-handed",
      style: "Medium",
      team: "VoxVelo Academy",
      createdAt: now - 18 * DAY,
    },
    {
      id: "p_kabir",
      name: "Kabir Singh",
      hand: "Left-handed",
      style: "Spin",
      team: "City Club",
      createdAt: now - 12 * DAY,
    },
  ];

  const sMorning: Session = {
    id: "s_morning",
    name: "Morning Nets",
    playerId: "p_arjun",
    createdAt: now - 2 * DAY,
    deliveries: [
      del(136.2, now - 2 * DAY + 8 * 60_000),
      del(138.5, now - 2 * DAY + 12 * 60_000),
      del(141.1, now - 2 * DAY + 16 * 60_000),
      del(139.4, now - 2 * DAY + 20 * 60_000),
      del(137.8, now - 2 * DAY + 24 * 60_000),
      del(135.0, now - 2 * DAY + 28 * 60_000, "medium"),
      del(133.6, now - 2 * DAY + 32 * 60_000),
      del(132.1, now - 2 * DAY + 36 * 60_000, "medium"),
    ],
  };

  const sEvening: Session = {
    id: "s_evening",
    name: "Evening Spell",
    playerId: "p_arjun",
    createdAt: now - 6 * 3600_000,
    deliveries: [
      del(134.8, now - 6 * 3600_000 + 4 * 60_000),
      del(137.2, now - 6 * 3600_000 + 8 * 60_000),
      del(138.9, now - 6 * 3600_000 + 12 * 60_000),
      del(136.4, now - 6 * 3600_000 + 16 * 60_000),
      del(133.1, now - 6 * 3600_000 + 20 * 60_000, "medium"),
      del(131.8, now - 6 * 3600_000 + 24 * 60_000),
    ],
  };

  const sYorkers: Session = {
    id: "s_yorkers",
    name: "Nets — Yorkers",
    playerId: "p_priya",
    createdAt: now - 3 * DAY,
    deliveries: [
      del(118.4, now - 3 * DAY + 10 * 60_000),
      del(121.0, now - 3 * DAY + 14 * 60_000),
      del(119.6, now - 3 * DAY + 18 * 60_000),
      del(116.2, now - 3 * DAY + 22 * 60_000, "medium"),
      del(114.8, now - 3 * DAY + 26 * 60_000),
      del(112.5, now - 3 * DAY + 30 * 60_000, "low"),
    ],
  };

  const sSpin: Session = {
    id: "s_spin",
    name: "Off-spin block",
    playerId: "p_kabir",
    createdAt: now - DAY,
    deliveries: [
      del(84.2, now - DAY + 5 * 60_000),
      del(86.1, now - DAY + 9 * 60_000),
      del(87.8, now - DAY + 13 * 60_000),
      del(85.4, now - DAY + 17 * 60_000),
      del(83.0, now - DAY + 21 * 60_000, "medium"),
      del(81.6, now - DAY + 25 * 60_000),
      del(80.2, now - DAY + 29 * 60_000, "medium"),
    ],
  };

  return {
    players,
    sessions: [sEvening, sSpin, sMorning, sYorkers],
    activePlayerId: "p_arjun",
  };
}
