export type Screen =
  | "home"
  | "sessions"
  | "session-detail"
  | "analyze"
  | "players"
  | "player-detail"
  | "team-dashboard"
  | "compare"
  | "more";

export type Confidence = "high" | "medium" | "low";
export type Handedness = "Right-handed" | "Left-handed";
export type BowlStyle = "Fast" | "Medium" | "Spin";
export type CameraAngle = "side" | "behind" | "other";

export interface Player {
  id: string;
  name: string;
  hand: Handedness;
  style: BowlStyle;
  team: string;
  createdAt: number;
}

export interface BounceAnalysis {
  releaseToBounceTime: number;
  bounceToArrivalTime: number;
  bounceDistance: number;
  stumpsDistance: number;
}

export interface Delivery {
  kmh: number;
  mph: number;
  time: number;
  distance: number;
  fps: number;
  confidence: Confidence;
  angle: CameraAngle;
  bounce: BounceAnalysis | null;
  ts: number;
}

export interface Session {
  id: string;
  name: string;
  playerId: string;
  createdAt: number;
  deliveries: Delivery[];
}

export interface DB {
  players: Player[];
  sessions: Session[];
  activePlayerId: string | null;
}

export interface SessionStats {
  fastest: number | null;
  slowest: number | null;
  avg: number | null;
  median: number | null;
  valid: number;
  low: number;
  consistency: number | null;
}

export interface CoachInsights {
  summary: string;
  observations: string[];
  drills: string[];
}

export const EMPTY_DB: DB = {
  players: [],
  sessions: [],
  activePlayerId: null,
};

export const TAB_SCREENS: Screen[] = [
  "home",
  "sessions",
  "analyze",
  "players",
  "more",
];
