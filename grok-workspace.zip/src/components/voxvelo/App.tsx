import { useVox } from "@/store/voxvelo";
import { useCallback, useEffect, useState } from "react";
import { AnalyzeScreen } from "./AnalyzeScreen";
import { HomeScreen } from "./HomeScreen";
import { IconDots, IconHome, IconList, IconPlay, IconUser } from "./icons";
import { ConfirmModal, PlayerModal, SessionModal, Toast } from "./Modals";
import { MoreScreen } from "./MoreScreen";
import { CompareScreen, PlayerDetailScreen, PlayersScreen, TeamDashboardScreen } from "./PlayersScreens";
import { SessionDetailScreen, SessionsScreen } from "./SessionsScreens";
import type { Screen } from "@/lib/voxvelo/types";

function navActive(screen: Screen, tab: Screen): boolean {
  if (tab === "sessions") return screen === "sessions" || screen === "session-detail";
  if (tab === "players")
    return (
      screen === "players" ||
      screen === "player-detail" ||
      screen === "team-dashboard" ||
      screen === "compare"
    );
  return screen === tab;
}

function BootScreen() {
  return (
    <div id="shell" className="vv-boot">
      <div className="brand">
        <div className="brand-mark" />
        <div>
          <div className="brand-name">VoxVelo</div>
          <div className="brand-sub">Measure. Analyze. Improve.</div>
        </div>
      </div>
    </div>
  );
}

export function VoxVeloApp() {
  const hydrated = useVox((s) => s.hydrated);
  const hydrate = useVox((s) => s.hydrate);
  const screen = useVox((s) => s.screen);
  const goto = useVox((s) => s.goto);
  const players = useVox((s) => s.players);
  const activePlayerId = useVox((s) => s.activePlayerId);
  const [forceResult, setForceResult] = useState(false);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const onBoard = () => setForceResult(true);
    window.addEventListener("voxvelo:speedboard", onBoard);
    return () => window.removeEventListener("voxvelo:speedboard", onBoard);
  }, []);

  const consumeForce = useCallback(() => setForceResult(false), []);

  const active = players.find((p) => p.id === activePlayerId);

  if (!hydrated) return <BootScreen />;

  return (
    <div id="shell">
      <div id="topbar">
        <div className="brand">
          <div className="brand-mark" />
          <div>
            <div className="brand-name">VoxVelo</div>
            <div className="brand-sub">Measure. Analyze. Improve.</div>
          </div>
        </div>
        <button className="player-chip" id="playerChipBtn" onClick={() => goto("players")}>
          <span className="dot" />
          <span id="playerChipName">{active ? active.name : "No player"}</span>
        </button>
      </div>

      <main>
        {screen === "home" ? <HomeScreen /> : null}
        {screen === "sessions" ? <SessionsScreen /> : null}
        {screen === "session-detail" ? <SessionDetailScreen /> : null}
        <div style={{ display: screen === "analyze" ? "block" : "none" }}>
          <AnalyzeScreen forceResultTab={forceResult} onForceResultConsumed={consumeForce} />
        </div>
        {screen === "players" ? <PlayersScreen /> : null}
        {screen === "player-detail" ? <PlayerDetailScreen /> : null}
        {screen === "team-dashboard" ? <TeamDashboardScreen /> : null}
        {screen === "compare" ? <CompareScreen /> : null}
        {screen === "more" ? <MoreScreen /> : null}
      </main>

      <nav id="navbar">
        <button
          className={`nav-btn${navActive(screen, "home") ? " active" : ""}`}
          onClick={() => goto("home")}
        >
          <IconHome />
          Home
        </button>
        <button
          className={`nav-btn${navActive(screen, "sessions") ? " active" : ""}`}
          onClick={() => goto("sessions")}
        >
          <IconList />
          Sessions
        </button>
        <button
          className={`nav-btn${navActive(screen, "analyze") ? " active" : ""}`}
          onClick={() => goto("analyze")}
        >
          <IconPlay />
          Analyze
        </button>
        <button
          className={`nav-btn${navActive(screen, "players") ? " active" : ""}`}
          onClick={() => goto("players")}
        >
          <IconUser />
          Players
        </button>
        <button
          className={`nav-btn${navActive(screen, "more") ? " active" : ""}`}
          onClick={() => goto("more")}
        >
          <IconDots />
          More
        </button>
      </nav>

      <PlayerModal />
      <SessionModal />
      <ConfirmModal />
      <Toast />
    </div>
  );
}
