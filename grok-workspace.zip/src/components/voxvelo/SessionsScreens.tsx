import { fmt, timeAgo } from "@/lib/voxvelo/format";
import { generateCoachInsights, sessionStats } from "@/lib/voxvelo/stats";
import { useVox } from "@/store/voxvelo";
import { HistogramChart, ProgressChart, SpeedChart } from "./Charts";
import { BackButton, CardListItem, CoachBox, Empty, SectionLabel, StatStrip } from "./ui";

export function SessionsScreen() {
  const sessions = useVox((s) => s.sessions);
  const players = useVox((s) => s.players);
  const goto = useVox((s) => s.goto);
  const openSessionModal = useVox((s) => s.openSessionModal);
  const showToast = useVox((s) => s.showToast);

  return (
    <section className="screen active" id="screen-sessions">
      <h1 className="page-title">Sessions</h1>
      <p className="page-lede">
        Every bowling session you've recorded, with speed and consistency at a glance.
      </p>
      <button
        className="btn primary block"
        onClick={() => {
          if (!players.length) {
            showToast("Add a player first, then start a session.");
            goto("players");
            return;
          }
          openSessionModal("create");
        }}
      >
        Start new session
      </button>
      <SectionLabel>History</SectionLabel>
      {!sessions.length ? (
        <Empty title="No sessions yet">Start a session and save a few deliveries to see them here.</Empty>
      ) : (
        sessions.map((s) => {
          const st = sessionStats(s);
          const player = players.find((p) => p.id === s.playerId);
          return (
            <CardListItem
              key={s.id}
              title={s.name}
              sub={`${player ? player.name : "—"} · ${s.deliveries.length} deliveries · ${timeAgo(s.createdAt)}`}
              value={st.avg ? fmt(st.avg, 1) : "—"}
              valueLabel="avg km/h"
              onClick={() => goto("session-detail", s.id)}
            />
          );
        })
      )}
    </section>
  );
}

export function SessionDetailScreen() {
  const id = useVox((s) => s.screenPayload);
  const sessions = useVox((s) => s.sessions);
  const players = useVox((s) => s.players);
  const goto = useVox((s) => s.goto);
  const s = sessions.find((x) => x.id === id);

  if (!s) {
    return (
      <section className="screen active">
        <BackButton label="Sessions" onClick={() => goto("sessions")} />
        <Empty title="Session not found">It may have been cleared from this device.</Empty>
      </section>
    );
  }

  const st = sessionStats(s);
  const player = players.find((p) => p.id === s.playerId);

  return (
    <section className="screen active" id="screen-session-detail">
      <BackButton label="Sessions" onClick={() => goto("sessions")} />
      <h1 className="page-title">{s.name}</h1>
      <p className="page-lede">
        {player ? player.name : "—"} · {new Date(s.createdAt).toLocaleString()}
      </p>
      <StatStrip
        rows={[
          { k: "Fastest", v: `${fmt(st.fastest, 1)} km/h` },
          { k: "Slowest", v: `${fmt(st.slowest, 1)} km/h` },
          { k: "Average", v: `${fmt(st.avg, 1)} km/h` },
          { k: "Median", v: `${fmt(st.median, 1)} km/h` },
          { k: "Consistency", v: st.consistency ? `${fmt(st.consistency, 0)}%` : "—" },
          { k: "Valid / low-confidence", v: `${st.valid} / ${st.low}` },
        ]}
      />
      <SectionLabel>Speed by delivery</SectionLabel>
      <div className="chart-box">
        <SpeedChart deliveries={s.deliveries} />
      </div>
      <SectionLabel>Distribution & session progress</SectionLabel>
      <div className="chart-grid">
        <div className="chart-box">
          <div className="chart-mini-label">Speed distribution</div>
          <HistogramChart deliveries={s.deliveries} />
        </div>
        <div className="chart-box">
          <div className="chart-mini-label">Progress (fatigue trend)</div>
          <ProgressChart deliveries={s.deliveries} />
        </div>
      </div>
      <SectionLabel>Deliveries</SectionLabel>
      <div className="chart-box" id="sdDeliveries">
        {s.deliveries.length ? (
          s.deliveries.map((d, i) => (
            <div className="deliv-row" key={`${d.ts}-${i}`}>
              <span className="n">#{i + 1}</span>
              <span>
                {new Date(d.ts).toLocaleTimeString()} · {d.confidence}
              </span>
              <span className="s">{fmt(d.kmh, 1)} km/h</span>
            </div>
          ))
        ) : (
          <Empty title="No deliveries saved yet" />
        )}
      </div>
      <SectionLabel>AI Cricket Coach</SectionLabel>
      <CoachBox insights={generateCoachInsights(s.deliveries)} />
    </section>
  );
}
