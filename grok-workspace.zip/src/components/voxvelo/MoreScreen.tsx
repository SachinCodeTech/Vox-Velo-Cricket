import { useVox } from "@/store/voxvelo";
import { SectionLabel } from "./ui";

export function MoreScreen() {
  const exportData = useVox((s) => s.exportData);
  const askConfirm = useVox((s) => s.askConfirm);
  const clearAllData = useVox((s) => s.clearAllData);

  return (
    <section className="screen active" id="screen-more">
      <h1 className="page-title">More</h1>
      <p className="page-lede">VoxVelo Cricket — your cricket performance lab.</p>
      <SectionLabel>Coming soon</SectionLabel>
      <div className="stat-strip">
        <div className="stat-row">
          <span className="k">Automatic ball tracking (needs a CV/pose model)</span>
          <span className="soon">Phase 3</span>
        </div>
        <div className="stat-row">
          <span className="k">Advanced biomechanics (needs a pose model)</span>
          <span className="soon">Phase 3</span>
        </div>
        <div className="stat-row">
          <span className="k">Cloud backup & billing</span>
          <span className="soon">Future</span>
        </div>
      </div>
      <SectionLabel>Data</SectionLabel>
      <button className="btn block" style={{ marginBottom: 10 }} onClick={() => void exportData()}>
        Export data (JSON)
      </button>
      <button
        className="btn block"
        onClick={() =>
          askConfirm({
            title: "Clear all local data",
            message:
              "This deletes all players, sessions and deliveries stored on this device. Continue?",
            confirmLabel: "Clear data",
            onConfirm: clearAllData,
          })
        }
      >
        Clear all local data
      </button>
      <p className="note" style={{ marginTop: 16 }}>
        All videos and measurements stay on this device by default. Nothing is uploaded unless you
        explicitly enable cloud AI analysis in a future update. The AI Coach runs entirely on your
        recorded measurements, on-device — it never invents numbers.
      </p>
    </section>
  );
}
