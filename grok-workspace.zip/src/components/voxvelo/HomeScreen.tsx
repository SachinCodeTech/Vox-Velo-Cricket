import { fmt, timeAgo } from "@/lib/voxvelo/format";
import { sessionStats } from "@/lib/voxvelo/stats";
import { useVox } from "@/store/voxvelo";
import { IconBolt, IconList } from "./icons";
import { CardListItem, Empty, SectionLabel, StatStrip } from "./ui";

export function HomeScreen() {
  const sessions = useVox((s) => s.sessions);
  const goto = useVox((s) => s.goto);

  const all = sessions.flatMap((s) => s.deliveries.map((d) => ({ ...d, sessionName: s.name })));
  const last = [...all].sort((a, b) => b.ts - a.ts)[0];
  const speeds = all.map((d) => d.kmh);
  const fastest = speeds.length ? Math.max(...speeds) : null;
  const avg = speeds.length ? speeds.reduce((a, b) => a + b, 0) / speeds.length : null;

  return (
    <section className="screen active" id="screen-home">
      <div className="hero">
        <div className="hero-label">Last recorded delivery</div>
        <div>
          <span className="hero-num">{last ? fmt(last.kmh, 1) : "—"}</span>
          <span className="hero-unit">km/h</span>
        </div>
        <div className="hero-foot">
          <div className="hero-meta">
            {last ? `${last.sessionName} · ${timeAgo(last.ts)}` : "No deliveries yet"}
          </div>
          <button className="hero-cta" onClick={() => goto("analyze")}>
            Analyze a delivery
          </button>
        </div>
      </div>

      <StatStrip
        rows={[
          { k: "Fastest recorded", v: `${fmt(fastest, 1)} km/h` },
          { k: "Average speed", v: `${fmt(avg, 1)} km/h` },
          { k: "Total deliveries", v: String(all.length) },
          { k: "Sessions logged", v: String(sessions.length) },
        ]}
      />

      <SectionLabel>Quick actions</SectionLabel>
      <div className="quick-grid">
        <button
          className="quick-btn"
          onClick={() => {
            goto("analyze");
            window.dispatchEvent(new CustomEvent("voxvelo:speedboard"));
          }}
        >
          <div className="qi">
            <IconBolt />
          </div>
          <div className="qt">Speed Board</div>
          <div className="qs">Live single-delivery readout</div>
        </button>
        <button className="quick-btn" onClick={() => goto("sessions")}>
          <div className="qi">
            <IconList />
          </div>
          <div className="qt">My Sessions</div>
          <div className="qs">Review past bowling sessions</div>
        </button>
      </div>

      <SectionLabel>Recent sessions</SectionLabel>
      {!sessions.length ? (
        <Empty title="No sessions yet">Analyze your first delivery to start a session.</Empty>
      ) : (
        sessions.slice(0, 3).map((s) => {
          const st = sessionStats(s);
          return (
            <CardListItem
              key={s.id}
              title={s.name}
              sub={`${s.deliveries.length} deliveries · ${timeAgo(s.createdAt)}`}
              value={fmt(st.avg, 1)}
              valueLabel="avg km/h"
              onClick={() => goto("session-detail", s.id)}
            />
          );
        })
      )}
    </section>
  );
}
