import type { BowlStyle, Handedness } from "@/lib/voxvelo/types";
import { useVox } from "@/store/voxvelo";
import { useEffect, useState } from "react";

export function PlayerModal() {
  const open = useVox((s) => s.playerModalOpen);
  const close = useVox((s) => s.closePlayerModal);
  const addPlayer = useVox((s) => s.addPlayer);
  const showToast = useVox((s) => s.showToast);
  const [name, setName] = useState("");
  const [hand, setHand] = useState<Handedness>("Right-handed");
  const [style, setStyle] = useState<BowlStyle>("Fast");
  const [team, setTeam] = useState("");

  useEffect(() => {
    if (open) {
      setName("");
      setTeam("");
      setHand("Right-handed");
      setStyle("Fast");
    }
  }, [open]);

  const save = () => {
    const trimmed = name.trim();
    if (!trimmed) {
      showToast("Enter a player name.");
      return;
    }
    addPlayer({ name: trimmed, hand, style, team: team.trim() });
    showToast("Player saved.");
  };

  return (
    <div
      className={`modal-bg${open ? " on" : ""}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <div className="modal">
        <h3>Add player</h3>
        <label className="field">
          <span className="fl">Name</span>
          <input
            type="text"
            placeholder="Player name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        <div className="calib-grid">
          <label className="field">
            <span className="fl">Handedness</span>
            <select value={hand} onChange={(e) => setHand(e.target.value as Handedness)}>
              <option>Right-handed</option>
              <option>Left-handed</option>
            </select>
          </label>
          <label className="field">
            <span className="fl">Style</span>
            <select value={style} onChange={(e) => setStyle(e.target.value as BowlStyle)}>
              <option>Fast</option>
              <option>Medium</option>
              <option>Spin</option>
            </select>
          </label>
        </div>
        <label className="field">
          <span className="fl">Team / Academy (optional)</span>
          <input
            type="text"
            placeholder="Optional"
            value={team}
            onChange={(e) => setTeam(e.target.value)}
          />
        </label>
        <div className="btn-row">
          <button className="btn ghost block" onClick={close}>
            Cancel
          </button>
          <button className="btn primary block" onClick={save}>
            Save player
          </button>
        </div>
      </div>
    </div>
  );
}

export function SessionModal() {
  const open = useVox((s) => s.sessionModalOpen);
  const mode = useVox((s) => s.sessionModalMode);
  const close = useVox((s) => s.closeSessionModal);
  const players = useVox((s) => s.players);
  const activePlayerId = useVox((s) => s.activePlayerId);
  const addSession = useVox((s) => s.addSession);
  const savePendingDelivery = useVox((s) => s.savePendingDelivery);
  const showToast = useVox((s) => s.showToast);
  const [name, setName] = useState("");
  const [playerId, setPlayerId] = useState("");

  useEffect(() => {
    if (open) {
      setName(`Session ${new Date().toLocaleDateString()}`);
      setPlayerId(activePlayerId || players[0]?.id || "");
    }
  }, [open, activePlayerId, players]);

  const confirm = () => {
    if (!playerId) {
      showToast("Add a player first.");
      return;
    }
    const sessionName = name.trim() || "Session";
    if (mode === "save-delivery") {
      const s = savePendingDelivery(sessionName, playerId);
      showToast(`Session "${s.name}" created and delivery saved.`);
    } else {
      const s = addSession(sessionName, playerId);
      showToast(`Session "${s.name}" created.`);
    }
  };

  return (
    <div
      className={`modal-bg${open ? " on" : ""}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <div className="modal">
        <h3>Session details</h3>
        <label className="field">
          <span className="fl">Session name</span>
          <input
            type="text"
            placeholder="e.g. Morning Nets"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        <label className="field">
          <span className="fl">Player</span>
          <select value={playerId} onChange={(e) => setPlayerId(e.target.value)}>
            {players.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
        <div className="btn-row">
          <button className="btn ghost block" onClick={close}>
            Cancel
          </button>
          <button className="btn primary block" onClick={confirm}>
            {mode === "save-delivery" ? "Save delivery" : "Create session"}
          </button>
        </div>
      </div>
    </div>
  );
}

export function ConfirmModal() {
  const confirm = useVox((s) => s.confirm);
  const close = useVox((s) => s.closeConfirm);
  return (
    <div
      className={`modal-bg${confirm ? " on" : ""}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <div className="modal">
        <h3>{confirm?.title ?? ""}</h3>
        <p className="page-lede" style={{ marginBottom: 18 }}>
          {confirm?.message ?? ""}
        </p>
        <div className="btn-row">
          <button className="btn ghost block" onClick={close}>
            Cancel
          </button>
          <button
            className="btn primary block"
            onClick={() => {
              confirm?.onConfirm();
              close();
            }}
          >
            {confirm?.confirmLabel ?? "Confirm"}
          </button>
        </div>
      </div>
    </div>
  );
}

export function Toast() {
  const toast = useVox((s) => s.toast);
  if (!toast) return null;
  return (
    <div className="vv-toast" role="status">
      {toast}
    </div>
  );
}
