import { fmt, kmhToMph } from "@/lib/voxvelo/format";
import type { CameraAngle, Confidence, Delivery } from "@/lib/voxvelo/types";
import { useVox } from "@/store/voxvelo";
import { useCallback, useEffect, useRef, useState } from "react";
import { PitchOverlay } from "./Charts";
import { ConfidChip, Empty, SectionLabel, StatStrip } from "./ui";

type Tab = "import" | "result";

interface SuggestedFrames {
  release: number;
  arrival: number;
}

function haptic() {
  try {
    navigator.vibrate?.(18);
  } catch {
    /* ignore */
  }
}

function seekTo(vid: HTMLVideoElement, t: number): Promise<void> {
  return new Promise((resolve) => {
    const onSeeked = () => {
      vid.removeEventListener("seeked", onSeeked);
      resolve();
    };
    vid.addEventListener("seeked", onSeeked);
    vid.currentTime = t;
  });
}

export function AnalyzeScreen({
  forceResultTab,
  onForceResultConsumed,
}: {
  forceResultTab: boolean;
  onForceResultConsumed: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const captureRef = useRef<HTMLInputElement>(null);
  const objectUrlRef = useRef<string | null>(null);

  const [tab, setTab] = useState<Tab>("import");
  const [hasVideo, setHasVideo] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [startMark, setStartMark] = useState<number | null>(null);
  const [endMark, setEndMark] = useState<number | null>(null);
  const [bounceMark, setBounceMark] = useState<number | null>(null);
  const [detectedFps, setDetectedFps] = useState<number | null>(null);
  const [fps, setFps] = useState("30");
  const [distance, setDistance] = useState("20.12");
  const [bounceDist, setBounceDist] = useState("");
  const [angle, setAngle] = useState<CameraAngle>("side");
  const [suggesting, setSuggesting] = useState(false);
  const [suggested, setSuggested] = useState<SuggestedFrames | null>(null);
  const [lastResult, setLastResult] = useState<Delivery | null>(null);

  const players = useVox((s) => s.players);
  const sessions = useVox((s) => s.sessions);
  const currentSessionId = useVox((s) => s.currentSessionId);
  const addDelivery = useVox((s) => s.addDelivery);
  const openSessionModal = useVox((s) => s.openSessionModal);
  const goto = useVox((s) => s.goto);
  const showToast = useVox((s) => s.showToast);

  useEffect(() => {
    if (forceResultTab) {
      setTab("result");
      onForceResultConsumed();
    }
  }, [forceResultTab, onForceResultConsumed]);

  const resetMarks = () => {
    setStartMark(null);
    setEndMark(null);
    setBounceMark(null);
    setSuggested(null);
    setDetectedFps(null);
    setCurrentTime(0);
  };

  const tryDetectFps = (vid: HTMLVideoElement) => {
    try {
      const v = vid as HTMLVideoElement & {
        captureStream?: () => MediaStream;
        webkitCaptureStream?: () => MediaStream;
      };
      const stream = v.captureStream?.() ?? v.webkitCaptureStream?.();
      const track = stream?.getVideoTracks()[0];
      const settings = track?.getSettings?.();
      if (settings?.frameRate) {
        const rounded = Math.round(settings.frameRate);
        setDetectedFps(rounded);
        setFps(String(rounded));
      }
      track?.stop?.();
    } catch {
      /* not supported */
    }
  };

  const loadFile = (file: File | undefined) => {
    if (!file) return;
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    const url = URL.createObjectURL(file);
    objectUrlRef.current = url;
    const vid = videoRef.current;
    if (vid) vid.src = url;
    setHasVideo(true);
    resetMarks();
  };

  useEffect(() => {
    return () => {
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    };
  }, []);

  const onMeta = () => {
    const vid = videoRef.current;
    if (!vid) return;
    setDuration(Number.isFinite(vid.duration) ? vid.duration : 0);
    tryDetectFps(vid);
  };

  const onTime = () => {
    const vid = videoRef.current;
    if (!vid) return;
    setCurrentTime(vid.currentTime);
  };

  const stepFrame = (nFrames: number) => {
    const vid = videoRef.current;
    if (!vid) return;
    const rate = parseFloat(fps) || 30;
    vid.pause();
    vid.currentTime = Math.max(0, Math.min(vid.duration || 0, vid.currentTime + nFrames / rate));
  };

  const markPoint = (which: "start" | "bounce" | "end") => {
    const vid = videoRef.current;
    if (!vid) return;
    const t = vid.currentTime;
    if (which === "start") setStartMark(t);
    else if (which === "bounce") setBounceMark(t);
    else setEndMark(t);
    haptic();
  };

  const suggestFrames = async () => {
    const vid = videoRef.current;
    if (!vid || !vid.duration || !Number.isFinite(vid.duration)) return;
    setSuggesting(true);
    const wasPaused = vid.paused;
    vid.pause();
    const cw = 64;
    const ch = 36;
    const canvas = document.createElement("canvas");
    canvas.width = cw;
    canvas.height = ch;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) {
      setSuggesting(false);
      showToast("Motion analysis is not supported on this device.");
      return;
    }
    const sampleCount = 30;
    const frames: { t: number; gray: Float32Array }[] = [];
    try {
      for (let i = 0; i <= sampleCount; i++) {
        const t = (i / sampleCount) * vid.duration;
        await seekTo(vid, t);
        ctx.drawImage(vid, 0, 0, cw, ch);
        const data = ctx.getImageData(0, 0, cw, ch).data;
        const gray = new Float32Array(cw * ch);
        for (let p = 0; p < cw * ch; p++) {
          gray[p] = (data[p * 4]! + data[p * 4 + 1]! + data[p * 4 + 2]!) / 3;
        }
        frames.push({ t, gray });
      }
      const motion: { t: number; v: number }[] = [];
      for (let i = 1; i < frames.length; i++) {
        let diff = 0;
        const a = frames[i]!.gray;
        const b = frames[i - 1]!.gray;
        for (let p = 0; p < a.length; p++) diff += Math.abs(a[p]! - b[p]!);
        motion.push({ t: frames[i]!.t, v: diff });
      }
      const mid = Math.max(1, Math.floor(motion.length * 0.5));
      const peak = (arr: { t: number; v: number }[]) =>
        arr.reduce((max, m) => (m.v > max.v ? m : max), arr[0]!);
      const releaseCandidate = peak(motion.slice(0, mid));
      const arrivalCandidate = peak(motion.slice(mid));
      setSuggested({ release: releaseCandidate.t, arrival: arrivalCandidate.t });
    } catch {
      showToast("Motion analysis is not supported on this device — mark frames manually.");
    } finally {
      setSuggesting(false);
      if (!wasPaused) void vid.play();
    }
  };

  const jumpToSuggestion = (which: "release" | "arrival") => {
    const vid = videoRef.current;
    if (!suggested || !vid) return;
    vid.currentTime = which === "release" ? suggested.release : suggested.arrival;
  };

  const calculateSpeed = () => {
    if (startMark === null || endMark === null) {
      showToast("Mark both the release frame and the arrival frame first.");
      return;
    }
    const dist = parseFloat(distance);
    const rate = parseFloat(fps);
    if (!dist || dist <= 0) {
      showToast("Enter a valid distance in meters.");
      return;
    }
    if (!rate || rate <= 0) {
      showToast("Enter a valid FPS.");
      return;
    }
    const time = Math.abs(endMark - startMark);
    if (time <= 0) {
      showToast("Start and end frames must differ.");
      return;
    }

    const mps = dist / time;
    const kmh = mps * 3.6;
    const mph = kmhToMph(kmh);

    let confidence: Confidence = "low";
    if (rate >= 120 && time >= 0.05) confidence = "high";
    else if (rate >= 60 && time >= 0.04) confidence = "high";
    else if (rate >= 30 && time >= 0.03) confidence = "medium";
    else confidence = "low";
    if (kmh > 180 || kmh < 40) confidence = "low";

    const result: Delivery = {
      kmh,
      mph,
      time,
      distance: dist,
      fps: rate,
      confidence,
      angle,
      bounce: null,
      ts: Date.now(),
    };

    if (bounceMark !== null) {
      const bDist = parseFloat(bounceDist);
      const releaseT = Math.min(startMark, endMark);
      const arrivalT = Math.max(startMark, endMark);
      const bounceOk = bDist > 0 && bounceMark > releaseT && bounceMark < arrivalT;
      result.bounce = bounceOk
        ? {
            releaseToBounceTime: Math.abs(bounceMark - startMark),
            bounceToArrivalTime: Math.abs(endMark - bounceMark),
            bounceDistance: bDist,
            stumpsDistance: Math.max(0, dist - bDist),
          }
        : null;
    }

    setLastResult(result);
    setTab("result");
    haptic();
  };

  const saveDelivery = useCallback(() => {
    if (!lastResult) return;
    if (!players.length) {
      showToast("Add a player first.");
      goto("players");
      return;
    }
    const sid =
      currentSessionId && sessions.find((s) => s.id === currentSessionId)
        ? currentSessionId
        : null;
    if (sid) {
      const s = sessions.find((x) => x.id === sid);
      addDelivery(sid, { ...lastResult, ts: Date.now() });
      showToast(`Delivery saved to "${s?.name ?? "session"}".`);
      return;
    }
    openSessionModal("save-delivery", { ...lastResult, ts: Date.now() });
  }, [
    lastResult,
    players.length,
    currentSessionId,
    sessions,
    addDelivery,
    showToast,
    goto,
    openSessionModal,
  ]);

  const fpsBadge = detectedFps
    ? `FPS ${detectedFps} (detected)`
    : "FPS — enter manually";

  return (
    <section className="screen active" id="screen-analyze">
      <h1 className="page-title">Analyze delivery</h1>
      <p className="page-lede">
        Import or record a bowling delivery, mark release, bounce and arrival, and get an estimated
        speed with a pitch overlay.
      </p>

      <div className="tabbar">
        <button id="tabImport" className={tab === "import" ? "on" : ""} onClick={() => setTab("import")}>
          Import / Record
        </button>
        <button id="tabResult" className={tab === "result" ? "on" : ""} onClick={() => setTab("result")}>
          Result
        </button>
      </div>

      <div id="paneImport" style={{ display: tab === "import" ? "block" : "none" }}>
        <div className="btn-row" style={{ marginBottom: 14 }}>
          <label className="btn block" style={{ textAlign: "center" }}>
            Import video
            <input
              ref={fileRef}
              type="file"
              accept="video/*"
              style={{ display: "none" }}
              onChange={(e) => loadFile(e.target.files?.[0])}
            />
          </label>
          <label className="btn block" style={{ textAlign: "center" }}>
            Record now
            <input
              ref={captureRef}
              type="file"
              accept="video/*"
              capture="environment"
              style={{ display: "none" }}
              onChange={(e) => loadFile(e.target.files?.[0])}
            />
          </label>
        </div>

        <div className="video-wrap" id="videoWrap" style={{ display: hasVideo ? "block" : "none" }}>
          <video
            id="vid"
            ref={videoRef}
            playsInline
            muted
            onLoadedMetadata={onMeta}
            onTimeUpdate={onTime}
          />
          <div className="frame-badge" id="fpsBadge">
            {fpsBadge}
          </div>
          <div className="marker-badge">
            <span className={startMark != null ? "set s" : ""}>
              {startMark != null ? `S ${startMark.toFixed(2)}s` : "S —"}
            </span>
            <span className={bounceMark != null ? "set b" : ""}>
              {bounceMark != null ? `B ${bounceMark.toFixed(2)}s` : "B —"}
            </span>
            <span className={endMark != null ? "set e" : ""}>
              {endMark != null ? `E ${endMark.toFixed(2)}s` : "E —"}
            </span>
          </div>
        </div>

        <div id="analyzeControls" style={{ display: hasVideo ? "block" : "none" }}>
          <div className="scrub-row">
            <input
              type="range"
              id="scrub"
              min={0}
              max={duration || 1}
              value={currentTime}
              step={0.01}
              onChange={(e) => {
                const vid = videoRef.current;
                if (vid) vid.currentTime = parseFloat(e.target.value);
              }}
            />
          </div>
          <div className="frame-step">
            <button type="button" onClick={() => stepFrame(-1)}>
              -1f
            </button>
            <button type="button" onClick={() => stepFrame(-5)}>
              -5f
            </button>
            <div className="cur">{currentTime.toFixed(3)}s</div>
            <button type="button" onClick={() => stepFrame(5)}>
              +5f
            </button>
            <button type="button" onClick={() => stepFrame(1)}>
              +1f
            </button>
          </div>

          <div className="mark-row">
            <div className="mark-btn s" onClick={() => markPoint("start")} role="button" tabIndex={0}>
              <div className="ml">RELEASE (start)</div>
              <div className="mv">{startMark != null ? `${startMark.toFixed(3)}s` : "not set"}</div>
            </div>
            <div className="mark-btn b" onClick={() => markPoint("bounce")} role="button" tabIndex={0}>
              <div className="ml">BOUNCE (optional)</div>
              <div className="mv">{bounceMark != null ? `${bounceMark.toFixed(3)}s` : "not set"}</div>
            </div>
            <div className="mark-btn e" onClick={() => markPoint("end")} role="button" tabIndex={0}>
              <div className="ml">ARRIVAL (end)</div>
              <div className="mv">{endMark != null ? `${endMark.toFixed(3)}s` : "not set"}</div>
            </div>
          </div>

          <button
            className="btn block"
            style={{ marginTop: 10 }}
            onClick={() => void suggestFrames()}
            disabled={suggesting}
          >
            {suggesting ? "Analyzing motion…" : "Suggest frames from motion"}
          </button>
          {suggested ? (
            <div id="suggestBox">
              <p className="note">
                Suggested from frame-to-frame motion, not a confirmed ball track — scrub and check
                before marking.
              </p>
              <div className="btn-row">
                <button className="btn ghost block" onClick={() => jumpToSuggestion("release")}>
                  Jump to suggested release
                </button>
                <button className="btn ghost block" onClick={() => jumpToSuggestion("arrival")}>
                  Jump to suggested arrival
                </button>
              </div>
            </div>
          ) : null}

          <SectionLabel>Measurement inputs</SectionLabel>
          <label className="field">
            <span className="fl">Distance (m) — release point to arrival/reference point</span>
            <input
              type="number"
              inputMode="decimal"
              placeholder="e.g. 20.12"
              step={0.01}
              value={distance}
              onChange={(e) => setDistance(e.target.value)}
            />
          </label>
          <label className="field">
            <span className="fl">Bounce distance (m) — release point to bounce, only if bounce marked</span>
            <input
              type="number"
              inputMode="decimal"
              placeholder="e.g. 15.5"
              step={0.01}
              value={bounceDist}
              onChange={(e) => setBounceDist(e.target.value)}
            />
          </label>
          <div className="calib-grid">
            <label className="field">
              <span className="fl">FPS</span>
              <input
                type="number"
                inputMode="numeric"
                placeholder="30"
                value={fps}
                onChange={(e) => setFps(e.target.value)}
              />
            </label>
            <label className="field">
              <span className="fl">Camera angle</span>
              <select value={angle} onChange={(e) => setAngle(e.target.value as CameraAngle)}>
                <option value="side">Side-on (recommended)</option>
                <option value="behind">Behind bowler</option>
                <option value="other">Other</option>
              </select>
            </label>
          </div>

          <button className="btn primary block" onClick={calculateSpeed}>
            Calculate speed
          </button>
          <p className="note">
            Estimated Speed — not a certified radar measurement. Accuracy depends on FPS, camera
            angle, calibration and ball visibility. Bounce marking is manual — the ball is never
            auto-tracked or fabricated.
          </p>
        </div>

        {!hasVideo ? (
          <div id="importEmpty" className="empty">
            <b>No video loaded</b>
            Import a clip from your gallery or record a new delivery to begin.
          </div>
        ) : null}
      </div>

      <div id="paneResult" style={{ display: tab === "result" ? "block" : "none" }}>
        {!lastResult ? (
          <Empty title="No result yet">Calculate a delivery in the Import tab first.</Empty>
        ) : (
          <div id="resultBox">
            <div className="speedboard">
              <div>
                <ConfidChip level={lastResult.confidence} />
              </div>
              <div className="sb-num">{fmt(lastResult.kmh, 1)}</div>
              <div className="sb-unit">
                km/h &nbsp;·&nbsp; <span>{fmt(lastResult.mph, 1)}</span> mph
              </div>
              <div className="sb-label">ESTIMATED BALL SPEED</div>
              <div className="sb-details">
                <div>
                  <div className="l">Flight time</div>
                  <div className="v">{fmt(lastResult.time, 3)}s</div>
                </div>
                <div>
                  <div className="l">Distance</div>
                  <div className="v">{fmt(lastResult.distance, 2)}m</div>
                </div>
                <div>
                  <div className="l">FPS</div>
                  <div className="v">{lastResult.fps}</div>
                </div>
              </div>
            </div>
            <p className={`note${lastResult.confidence === "low" ? " warn" : ""}`}>
              {lastResult.confidence === "low"
                ? "Low confidence — reposition camera, improve lighting, or use a higher-FPS recording for a more reliable estimate."
                : "Method: Video Frame Analysis (Distance ÷ Flight Time). Estimated speed, not a certified radar measurement."}
            </p>

            {bounceMark !== null ? (
              <div id="bounceBox">
                <SectionLabel>Bounce / pitch analysis</SectionLabel>
                <StatStrip
                  rows={[
                    {
                      k: "Release → bounce time",
                      v: lastResult.bounce ? `${fmt(lastResult.bounce.releaseToBounceTime, 3)}s` : "—",
                    },
                    {
                      k: "Bounce → arrival time",
                      v: lastResult.bounce ? `${fmt(lastResult.bounce.bounceToArrivalTime, 3)}s` : "—",
                    },
                    {
                      k: "Bounce distance",
                      v: lastResult.bounce
                        ? `${fmt(lastResult.bounce.bounceDistance, 2)}m`
                        : "enter bounce distance",
                    },
                    {
                      k: "Bounce → stumps (est.)",
                      v: lastResult.bounce ? `${fmt(lastResult.bounce.stumpsDistance, 2)}m` : "—",
                    },
                  ]}
                />
                <div className="pitch-box">
                  <div className="l">
                    Pitch overlay — release / bounce / arrival, to scale on measured distance
                  </div>
                  <PitchOverlay
                    bounceDist={lastResult.bounce?.bounceDistance ?? null}
                    totalDist={lastResult.distance}
                  />
                </div>
              </div>
            ) : null}

            <div className="btn-row" style={{ marginTop: 14 }}>
              <button className="btn teal block" onClick={saveDelivery}>
                Save to session
              </button>
              <button className="btn ghost block" onClick={() => setTab("import")}>
                Re-mark frames
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
