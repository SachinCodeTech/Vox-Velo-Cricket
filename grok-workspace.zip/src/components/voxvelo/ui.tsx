import type { CoachInsights } from "@/lib/voxvelo/types";
import type { ReactNode } from "react";

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <b>{title}</b>
      {children}
    </div>
  );
}

export function StatStrip({ rows }: { rows: { k: string; v: string }[] }) {
  return (
    <div className="stat-strip">
      {rows.map((r) => (
        <div className="stat-row" key={r.k}>
          <span className="k">{r.k}</span>
          <span className="v">{r.v}</span>
        </div>
      ))}
    </div>
  );
}

export function CardListItem({
  title,
  sub,
  value,
  valueLabel,
  onClick,
}: {
  title: ReactNode;
  sub: ReactNode;
  value: ReactNode;
  valueLabel?: string;
  onClick: () => void;
}) {
  return (
    <div
      className="card-list-item"
      onClick={onClick}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick();
        }
      }}
      role="button"
      tabIndex={0}
    >
      <div>
        <div className="cli-title">{title}</div>
        <div className="cli-sub">{sub}</div>
      </div>
      <div className="cli-val">
        {value}
        {valueLabel ? <small>{valueLabel}</small> : null}
      </div>
    </div>
  );
}

export function CoachBox({ insights }: { insights: CoachInsights }) {
  return (
    <div className="coach-box">
      <div className="coach-summary">{insights.summary}</div>
      {insights.observations.map((o) => (
        <div className="coach-obs" key={o}>
          <span className="dotm" />
          <span>{o}</span>
        </div>
      ))}
      {insights.drills.length ? (
        <div className="coach-drills">
          <div className="dl">SUGGESTED DRILLS</div>
          {insights.drills.map((d) => (
            <div className="coach-drill" key={d}>
              • {d}
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <div className="section-label">{children}</div>;
}

export function BackButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button className="btn ghost" onClick={onClick} style={{ marginBottom: 14 }}>
      ← {label}
    </button>
  );
}

export function ConfidChip({ level }: { level: "high" | "medium" | "low" }) {
  return (
    <span className={`confid ${level}`}>
      <span className="dot" />
      Confidence: {level.toUpperCase()}
    </span>
  );
}
