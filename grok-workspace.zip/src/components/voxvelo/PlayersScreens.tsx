import { fmt, timeAgo } from "@/lib/voxvelo/format";
import { generateCoachInsights, sessionStats } from "@/lib/voxvelo/stats";
import { useVox } from "@/store/voxvelo";
import { useMemo, useState } from "react";
import { TrendChart } from "./Charts";
import { BackButton, CardListItem, CoachBox, Empty, SectionLabel, StatStrip } from "./ui";

export function PlayersScreen() {
  const players = useVox((s) => s.players);
  const sessions = useVox((s) => s.sessions);
  const activePlayerId = useVox((s) => s.activePlayerId);
  const goto = useVox((s) => s.goto);
  const openPlayerModal = useVox((s) => s.openPlayerModal);

  return (
    <section className="screen active" id="screen-players">
      <h1 className="page-title">Players</h1>
      <p className="page-lede">Create a profile for each bowler you track.</p>
      <button className="btn primary block" onClick={openPlayerModal}>
        Add player
      </button>
      <div className="btn-row" style={{ marginTop: 10 }}>
        <button className="btn block" onClick={() => goto("team-dashboard")}>
          Team / academy view
        </button>
        <button className="btn block" onClick={() => goto("compare")}>
          Compare
        </button>
      </div>
      <SectionLabel>All players</SectionLabel>
      {!players.length ? (
        <Empty title="No players yet">Add a player to start tracking their sessions.</Empty>
      ) : (
        players.map((p) => {
          const speeds = sessions
            .filter((s) => s.playerId === p.id)
            .flatMap((s) => s.deliveries.map((d) => d.kmh));
          const best = speeds.length ? Math.max(...speeds) : null;
          return (
            <CardListItem
              key={p.id}
              title={
                <>
                  {p.name}{" "}
                  {p.id === activePlayerId ? (
                    <>
                      &nbsp;·&nbsp;
                      <span style={{ color: "var(--teal)", fontSize: 11 }}>active</span>
                    </>
                  ) : null}
                </>
              }
              sub={`${p.style} · ${p.hand}${p.team ? ` · ${p.team}` : ""}`}
              value={best ? fmt(best, 1) : "—"}
              valueLabel="best km/h"
              onClick={() => goto("player-detail", p.id)}
            />
          );
        })
      )}
    </section>
  );
}

export function PlayerDetailScreen() {
  const id = useVox((s) => s.screenPayload);
  const players = useVox((s) => s.players);
  const sessions = useVox((s) => s.sessions);
  const goto = useVox((s) => s.goto);
  const setActivePlayer = useVox((s) => s.setActivePlayer);
  const showToast = useVox((s) => s.showToast);
  const p = players.find((x) => x.id === id);

  if (!p) {
    return (
      <section className="screen active">
        <BackButton label="Players" onClick={() => goto("players")} />
        <Empty title="Player not found" />
      </section>
    );
  }

  const playerSessions = sessions
    .filter((s) => s.playerId === p.id)
    .slice()
    .sort((a, b) => a.createdAt - b.createdAt);
  const allDeliveries = playerSessions.flatMap((s) => s.deliveries);
  const speeds = allDeliveries.map((d) => d.kmh);
  const best = speeds.length ? Math.max(...speeds) : null;
  const avg = speeds.length ? speeds.reduce((a, b) => a + b, 0) / speeds.length : null;
  const sessionAvgs = playerSessions.map((s) => sessionStats(s).avg).filter((v): v is number => v != null);

  return (
    <section className="screen active" id="screen-player-detail">
      <BackButton label="Players" onClick={() => goto("players")} />
      <h1 className="page-title">{p.name}</h1>
      <p className="page-lede">
        {p.style} · {p.hand}
        {p.team ? ` · ${p.team}` : ""}
      </p>
      <StatStrip
        rows={[
          { k: "Best delivery", v: `${fmt(best, 1)} km/h` },
          { k: "Overall average", v: `${fmt(avg, 1)} km/h` },
          { k: "Sessions", v: String(playerSessions.length) },
          { k: "Total deliveries", v: String(allDeliveries.length) },
        ]}
      />
      <SectionLabel>Performance trend — average speed by session</SectionLabel>
      <div className="chart-box">
        <TrendChart values={sessionAvgs} />
      </div>
      <SectionLabel>AI Cricket Coach — career summary</SectionLabel>
      <CoachBox insights={generateCoachInsights(allDeliveries)} />
      <SectionLabel>Sessions</SectionLabel>
      {playerSessions.length ? (
        [...playerSessions].reverse().map((s) => {
          const st = sessionStats(s);
          return (
            <CardListItem
              key={s.id}
              title={s.name}
              sub={`${s.deliveries.length} deliveries · ${timeAgo(s.createdAt)}`}
              value={fmt(st.avg, 1)}
              valueLabel="avg km/h"
              onClick={() => goto("session-detail", s.id)}
            />
          );
        })
      ) : (
        <Empty title="No sessions for this player yet." />
      )}
      <button
        className="btn block"
        style={{ marginTop: 16 }}
        onClick={() => {
          setActivePlayer(p.id);
          showToast(`${p.name} is now the active player.`);
        }}
      >
        Set as active player
      </button>
    </section>
  );
}

export function TeamDashboardScreen() {
  const players = useVox((s) => s.players);
  const sessions = useVox((s) => s.sessions);
  const goto = useVox((s) => s.goto);

  const groups: Record<string, typeof players> = {};
  players.forEach((p) => {
    const key = p.team && p.team.trim() ? p.team.trim() : "Unassigned";
    (groups[key] = groups[key] || []).push(p);
  });
  const keys = Object.keys(groups).sort((a, b) =>
    a === "Unassigned" ? 1 : b === "Unassigned" ? -1 : a.localeCompare(b),
  );

  return (
    <section className="screen active" id="screen-team-dashboard">
      <BackButton label="Players" onClick={() => goto("players")} />
      <h1 className="page-title">Team & academy view</h1>
      <p className="page-lede">
        Players grouped by the team/academy on their profile, with squad-level speed stats.
      </p>
      {!keys.length ? (
        <Empty title="No players yet">Add players with a team/academy to see squad stats here.</Empty>
      ) : (
        keys.map((k) => {
          const roster = groups[k]!;
          const speeds = roster.flatMap((p) =>
            sessions.filter((s) => s.playerId === p.id).flatMap((s) => s.deliveries.map((d) => d.kmh)),
          );
          const fastest = speeds.length ? Math.max(...speeds) : null;
          const avg = speeds.length ? speeds.reduce((a, b) => a + b, 0) / speeds.length : null;
          return (
            <div className="team-card" key={k}>
              <h4>{k}</h4>
              <div className="ts">
                {roster.length} player{roster.length === 1 ? "" : "s"} · fastest {fmt(fastest, 1)} km/h ·
                avg {fmt(avg, 1)} km/h
              </div>
              <div className="team-roster">
                {roster.map((p) => (
                  <span
                    key={p.id}
                    onClick={() => goto("player-detail", p.id)}
                    style={{ cursor: "pointer" }}
                    role="button"
                    tabIndex={0}
                  >
                    {p.name}
                  </span>
                ))}
              </div>
            </div>
          );
        })
      )}
    </section>
  );
}

export function CompareScreen() {
  const players = useVox((s) => s.players);
  const sessions = useVox((s) => s.sessions);
  const goto = useVox((s) => s.goto);
  const [mode, setMode] = useState<"players" | "sessions">("players");
  const items = mode === "players" ? players : sessions;
  const [idA, setIdA] = useState(items[0]?.id ?? "");
  const [idB, setIdB] = useState(items[1]?.id ?? items[0]?.id ?? "");

  const switchMode = (next: "players" | "sessions") => {
    setMode(next);
    const nextItems = next === "players" ? players : sessions;
    setIdA(nextItems[0]?.id ?? "");
    setIdB(nextItems[1]?.id ?? nextItems[0]?.id ?? "");
  };

  const stA = useMemo(() => {
    if (mode === "players") {
      return sessionStats({
        deliveries: sessions.filter((s) => s.playerId === idA).flatMap((s) => s.deliveries),
      });
    }
    const s = sessions.find((x) => x.id === idA);
    return s ? sessionStats(s) : sessionStats({ deliveries: [] });
  }, [mode, idA, sessions]);

  const stB = useMemo(() => {
    if (mode === "players") {
      return sessionStats({
        deliveries: sessions.filter((s) => s.playerId === idB).flatMap((s) => s.deliveries),
      });
    }
    const s = sessions.find((x) => x.id === idB);
    return s ? sessionStats(s) : sessionStats({ deliveries: [] });
  }, [mode, idB, sessions]);

  const nameA = items.find((it) => it.id === idA)?.name ?? "—";
  const nameB = items.find((it) => it.id === idB)?.name ?? "—";
  const rows: [string, "fastest" | "avg" | "consistency" | "valid", string][] = [
    ["Fastest", "fastest", "km/h"],
    ["Average", "avg", "km/h"],
    ["Consistency", "consistency", "%"],
    ["Deliveries", "valid", ""],
  ];

  return (
    <section className="screen active" id="screen-compare">
      <BackButton label="Players" onClick={() => goto("players")} />
      <h1 className="page-title">Compare</h1>
      <p className="page-lede">Player vs player, or session vs session.</p>
      <div className="seg" style={{ marginBottom: 16 }}>
        <button className={mode === "players" ? "on" : ""} onClick={() => switchMode("players")}>
          Players
        </button>
        <button className={mode === "sessions" ? "on" : ""} onClick={() => switchMode("sessions")}>
          Sessions
        </button>
      </div>
      <div className="calib-grid">
        <label className="field">
          <span className="fl">A</span>
          <select value={idA} onChange={(e) => setIdA(e.target.value)}>
            {items.map((it) => (
              <option key={it.id} value={it.id}>
                {it.name}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span className="fl">B</span>
          <select value={idB} onChange={(e) => setIdB(e.target.value)}>
            {items.map((it) => (
              <option key={it.id} value={it.id}>
                {it.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      {items.length < 2 ? (
        <Empty title={`Add at least two ${mode} with saved deliveries to compare.`} />
      ) : (
        <div className="chart-box">
          <div className="cmp-row">
            <b>{nameA}</b>
            <span className="cmp-label">METRIC</span>
            <b style={{ textAlign: "right" }}>{nameB}</b>
          </div>
          {rows.map(([label, key, unit]) => {
            const a = stA[key];
            const b = stB[key];
            const aWin = a != null && b != null && a > b;
            const bWin = a != null && b != null && b > a;
            return (
              <div className="cmp-row" key={label}>
                <span className={`cv${aWin ? " win" : ""}`}>
                  {a != null ? fmt(a, key === "valid" ? 0 : 1) : "—"}
                  {unit && a != null ? ` ${unit}` : ""}
                </span>
                <span className="cmp-label">{label}</span>
                <span className={`cv${bWin ? " win" : ""}`}>
                  {b != null ? fmt(b, key === "valid" ? 0 : 1) : "—"}
                  {unit && b != null ? ` ${unit}` : ""}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
