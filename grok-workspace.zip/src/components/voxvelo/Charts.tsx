import type { Delivery } from "@/lib/voxvelo/types";

export function SpeedChart({ deliveries }: { deliveries: Delivery[] }) {
  const w = 320;
  const h = 120;
  const pad = 10;
  if (!deliveries.length) {
    return (
      <svg viewBox="0 0 320 120" width="100%" height="120" aria-label="Speed chart">
        <text x="160" y="60" fill="#5B677A" fontSize="11" textAnchor="middle">
          No data yet
        </text>
      </svg>
    );
  }
  const speeds = deliveries.map((d) => d.kmh);
  const min = Math.min(...speeds);
  const max = Math.max(...speeds);
  const range = max - min || 1;
  const pts = speeds.map((v, i) => {
    const x = pad + (i / Math.max(1, speeds.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    return [x, y] as const;
  });
  const path = pts
    .map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`)
    .join(" ");
  return (
    <svg viewBox="0 0 320 120" width="100%" height="120" aria-label="Speed by delivery">
      <path d={path} fill="none" stroke="#2DD4BF" strokeWidth="1.6" />
      {pts.map((p, i) => (
        <circle key={i} cx={p[0].toFixed(1)} cy={p[1].toFixed(1)} r="2.6" fill="#FF4B3E" />
      ))}
    </svg>
  );
}

export function HistogramChart({ deliveries }: { deliveries: Delivery[] }) {
  const w = 150;
  const h = 90;
  const pad = 8;
  const speeds = deliveries.map((d) => d.kmh);
  if (speeds.length < 2) {
    return (
      <svg viewBox="0 0 150 90" width="100%" height="90" aria-label="Speed distribution">
        <text x={w / 2} y={h / 2} fill="#5B677A" fontSize="9" textAnchor="middle">
          Needs 2+ deliveries
        </text>
      </svg>
    );
  }
  const min = Math.min(...speeds);
  const max = Math.max(...speeds);
  const range = max - min || 1;
  const bucketCount = 5;
  const buckets = new Array(bucketCount).fill(0) as number[];
  speeds.forEach((v) => {
    let idx = Math.floor(((v - min) / range) * bucketCount);
    if (idx >= bucketCount) idx = bucketCount - 1;
    if (idx < 0) idx = 0;
    buckets[idx]! += 1;
  });
  const maxCount = Math.max(...buckets);
  const bw = (w - pad * 2) / bucketCount;
  return (
    <svg viewBox="0 0 150 90" width="100%" height="90" aria-label="Speed distribution">
      {buckets.map((c, i) => {
        const bh = maxCount ? (c / maxCount) * (h - pad * 2 - 12) : 0;
        const x = pad + i * bw;
        const y = h - pad - bh;
        return (
          <rect
            key={i}
            x={(x + 2).toFixed(1)}
            y={y.toFixed(1)}
            width={(bw - 4).toFixed(1)}
            height={bh.toFixed(1)}
            fill="#2DD4BF"
            rx="2"
          />
        );
      })}
      <line x1={pad} y1={h - pad} x2={w - pad} y2={h - pad} stroke="#26304366" />
    </svg>
  );
}

export function ProgressChart({ deliveries }: { deliveries: Delivery[] }) {
  const w = 150;
  const h = 90;
  const pad = 8;
  if (!deliveries.length) {
    return (
      <svg viewBox="0 0 150 90" width="100%" height="90" aria-label="Session progress">
        <text x={w / 2} y={h / 2} fill="#5B677A" fontSize="9" textAnchor="middle">
          No data yet
        </text>
      </svg>
    );
  }
  const speeds = deliveries.map((d) => d.kmh);
  const cum: number[] = [];
  let sum = 0;
  speeds.forEach((v, i) => {
    sum += v;
    cum.push(sum / (i + 1));
  });
  const min = Math.min(...cum);
  const max = Math.max(...cum);
  const range = max - min || 1;
  const pts = cum.map((v, i) => {
    const x = pad + (i / Math.max(1, cum.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    return [x, y] as const;
  });
  const path = pts
    .map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`)
    .join(" ");
  return (
    <svg viewBox="0 0 150 90" width="100%" height="90" aria-label="Fatigue trend">
      <path d={path} fill="none" stroke="#F4B740" strokeWidth="1.6" />
    </svg>
  );
}

export function TrendChart({ values }: { values: number[] }) {
  const w = 320;
  const h = 120;
  const pad = 10;
  if (values.length < 2) {
    return (
      <svg viewBox="0 0 320 120" width="100%" height="120" aria-label="Performance trend">
        <text x={w / 2} y={h / 2} fill="#5B677A" fontSize="11" textAnchor="middle">
          Needs 2+ sessions with deliveries
        </text>
      </svg>
    );
  }
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = pad + (i / (values.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    return [x, y] as const;
  });
  const path = pts
    .map((pt, i) => `${i === 0 ? "M" : "L"}${pt[0].toFixed(1)},${pt[1].toFixed(1)}`)
    .join(" ");
  return (
    <svg viewBox="0 0 320 120" width="100%" height="120" aria-label="Average speed by session">
      <path d={path} fill="none" stroke="#F4B740" strokeWidth="1.6" />
      {pts.map((pt, i) => (
        <circle key={i} cx={pt[0].toFixed(1)} cy={pt[1].toFixed(1)} r="2.8" fill="#F4B740" />
      ))}
    </svg>
  );
}

export function PitchOverlay({
  bounceDist,
  totalDist,
}: {
  bounceDist: number | null;
  totalDist: number;
}) {
  const w = 320;
  const h = 70;
  const pad = 24;
  const frac =
    bounceDist != null ? Math.max(0, Math.min(1, bounceDist / totalDist)) : null;
  const y = h / 2;
  const releaseX = pad;
  const arrivalX = w - pad;
  const bounceX = frac != null ? releaseX + frac * (arrivalX - releaseX) : null;
  return (
    <svg viewBox="0 0 320 70" width="100%" height="70" aria-label="Pitch overlay">
      <line x1={releaseX} y1={y} x2={arrivalX} y2={y} stroke="#26304366" strokeWidth="2" />
      <circle cx={releaseX} cy={y} r="5" fill="#2DD4BF" />
      <text x={releaseX} y={y - 12} fontSize="9" fill="#8B96A8" textAnchor="middle">
        Release
      </text>
      {bounceX != null ? (
        <>
          <path
            d={`M${releaseX},${y} Q${(releaseX + bounceX) / 2},${y - 26} ${bounceX},${y}`}
            fill="none"
            stroke="#F4B740"
            strokeWidth="1.6"
            strokeDasharray="3 3"
          />
          <circle cx={bounceX} cy={y} r="5" fill="#F4B740" />
          <text x={bounceX} y={y + 18} fontSize="9" fill="#8B96A8" textAnchor="middle">
            Bounce
          </text>
          <path
            d={`M${bounceX},${y} Q${(bounceX + arrivalX) / 2},${y - 18} ${arrivalX},${y}`}
            fill="none"
            stroke="#FF4B3E"
            strokeWidth="1.6"
            strokeDasharray="3 3"
          />
        </>
      ) : (
        <path
          d={`M${releaseX},${y} Q${(releaseX + arrivalX) / 2},${y - 24} ${arrivalX},${y}`}
          fill="none"
          stroke="#FF4B3E"
          strokeWidth="1.6"
          strokeDasharray="3 3"
        />
      )}
      <circle cx={arrivalX} cy={y} r="5" fill="#FF4B3E" />
      <text x={arrivalX} y={y - 12} fontSize="9" fill="#8B96A8" textAnchor="middle">
        Arrival
      </text>
    </svg>
  );
}
