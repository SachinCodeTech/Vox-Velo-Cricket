import { create } from "zustand";
import { exportDB, loadDB, saveDB } from "@/lib/voxvelo/storage";
import { uid } from "@/lib/voxvelo/format";
import { EMPTY_DB, TAB_SCREENS, type DB, type Delivery, type Player, type Screen, type Session } from "@/lib/voxvelo/types";

export interface ConfirmState {
  title: string;
  message: string;
  confirmLabel: string;
  onConfirm: () => void;
}

interface VoxState extends DB {
  hydrated: boolean;
  screen: Screen;
  screenPayload: string | null;
  currentSessionId: string | null;
  toast: string | null;
  confirm: ConfirmState | null;
  playerModalOpen: boolean;
  sessionModalOpen: boolean;
  sessionModalMode: "create" | "save-delivery";
  pendingDelivery: Delivery | null;

  hydrate: () => void;
  goto: (screen: Screen, payload?: string | null) => void;
  showToast: (message: string) => void;
  clearToast: () => void;
  askConfirm: (c: ConfirmState) => void;
  closeConfirm: () => void;
  openPlayerModal: () => void;
  closePlayerModal: () => void;
  openSessionModal: (mode: "create" | "save-delivery", pending?: Delivery | null) => void;
  closeSessionModal: () => void;
  addPlayer: (input: Omit<Player, "id" | "createdAt">) => Player;
  setActivePlayer: (id: string) => void;
  addSession: (name: string, playerId: string) => Session;
  addDelivery: (sessionId: string, delivery: Delivery) => void;
  savePendingDelivery: (name: string, playerId: string) => Session;
  exportData: () => Promise<void>;
  clearAllData: () => void;
}

let toastTimer: ReturnType<typeof setTimeout> | null = null;

function persist(get: () => VoxState) {
  const { players, sessions, activePlayerId } = get();
  saveDB({ players, sessions, activePlayerId });
}

function applyHistory(screen: Screen, payload: string | null, isTab: boolean) {
  if (typeof window === "undefined") return;
  const hash = payload ? `#${screen}/${payload}` : `#${screen}`;
  const state = { screen, payload };
  if (isTab) window.history.replaceState(state, "", hash);
  else window.history.pushState(state, "", hash);
}

export const useVox = create<VoxState>((set, get) => ({
  ...EMPTY_DB,
  hydrated: false,
  screen: "home",
  screenPayload: null,
  currentSessionId: null,
  toast: null,
  confirm: null,
  playerModalOpen: false,
  sessionModalOpen: false,
  sessionModalMode: "create",
  pendingDelivery: null,

  hydrate: () => {
    if (get().hydrated) return;
    const db = loadDB();
    let screen: Screen = "home";
    let payload: string | null = null;
    if (typeof window !== "undefined") {
      const raw = window.location.hash.replace(/^#/, "");
      const [name, id] = raw.split("/");
      const allowed: Screen[] = [
        "home",
        "sessions",
        "session-detail",
        "analyze",
        "players",
        "player-detail",
        "team-dashboard",
        "compare",
        "more",
      ];
      if (name && (allowed as string[]).includes(name)) {
        screen = name as Screen;
        payload = id || null;
      }
      window.history.replaceState({ screen, payload }, "", payload ? `#${screen}/${payload}` : `#${screen}`);
      window.addEventListener("popstate", (e) => {
        const s = e.state as { screen?: Screen; payload?: string | null } | null;
        if (s?.screen) {
          set({ screen: s.screen, screenPayload: s.payload ?? null });
          window.scrollTo(0, 0);
        }
      });
    }
    set({ ...db, hydrated: true, screen, screenPayload: payload });
  },

  goto: (screen, payload = null) => {
    const isTab = TAB_SCREENS.includes(screen);
    applyHistory(screen, payload, isTab);
    set({ screen, screenPayload: payload });
    if (typeof window !== "undefined") window.scrollTo(0, 0);
  },

  showToast: (message) => {
    if (toastTimer) clearTimeout(toastTimer);
    set({ toast: message });
    toastTimer = setTimeout(() => set({ toast: null }), 2800);
  },

  clearToast: () => set({ toast: null }),

  askConfirm: (c) => set({ confirm: c }),
  closeConfirm: () => set({ confirm: null }),

  openPlayerModal: () => set({ playerModalOpen: true }),
  closePlayerModal: () => set({ playerModalOpen: false }),

  openSessionModal: (mode, pending = null) =>
    set({ sessionModalOpen: true, sessionModalMode: mode, pendingDelivery: pending }),
  closeSessionModal: () =>
    set({ sessionModalOpen: false, pendingDelivery: null }),

  addPlayer: (input) => {
    const player: Player = { ...input, id: uid("p"), createdAt: Date.now() };
    set((s) => ({
      players: [...s.players, player],
      activePlayerId: s.activePlayerId ?? player.id,
      playerModalOpen: false,
    }));
    persist(get);
    return player;
  },

  setActivePlayer: (id) => {
    set({ activePlayerId: id });
    persist(get);
  },

  addSession: (name, playerId) => {
    const session: Session = {
      id: uid("s"),
      name,
      playerId,
      createdAt: Date.now(),
      deliveries: [],
    };
    set((s) => ({
      sessions: [session, ...s.sessions],
      currentSessionId: session.id,
      sessionModalOpen: false,
      pendingDelivery: null,
    }));
    persist(get);
    return session;
  },

  addDelivery: (sessionId, delivery) => {
    set((s) => ({
      sessions: s.sessions.map((sess) =>
        sess.id === sessionId
          ? { ...sess, deliveries: [...sess.deliveries, delivery] }
          : sess,
      ),
      currentSessionId: sessionId,
    }));
    persist(get);
  },

  savePendingDelivery: (name, playerId) => {
    const pending = get().pendingDelivery;
    const session: Session = {
      id: uid("s"),
      name,
      playerId,
      createdAt: Date.now(),
      deliveries: pending ? [{ ...pending }] : [],
    };
    set((s) => ({
      sessions: [session, ...s.sessions],
      currentSessionId: session.id,
      sessionModalOpen: false,
      pendingDelivery: null,
    }));
    persist(get);
    return session;
  },

  exportData: async () => {
    const { players, sessions, activePlayerId, showToast } = get();
    const how = await exportDB({ players, sessions, activePlayerId });
    showToast(how === "shared" ? "Export shared." : "Export downloaded.");
  },

  clearAllData: () => {
    saveDB(EMPTY_DB);
    set({
      ...EMPTY_DB,
      currentSessionId: null,
      confirm: null,
    });
    get().showToast("Local data cleared.");
  },
}));
